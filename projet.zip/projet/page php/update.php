<?php
session_start();
require_once("connection.php");
$ident_m='';
$ident_e='';
$ident_f='';
$ident_a='';

if (isset($_GET['ident_m'])) {
  $id_bn=$_GET['ident_m'];
  $ident_m='true';
  $req = "select * from benevol where id_benevol ='$id_bn'";
  $res = mysqli_query($connect,$req);
  $ligne = mysqli_fetch_array($res);
}
  
if (isset($_POST['botton_b'])) {
   $id_benevol=$_POST['id_b'];
   $nom=$_POST['nom'];
   $prenom=$_POST['prenom'];
   $email=$_POST['email'];
   $mot_pass=$_POST['mot_pass'];
   $adresse=$_POST['adresse'];
   $num_tele=$_POST['num_tele'];
   $date_n =$_POST['date_n'];
   $sexe =$_POST['sexe'];
   $description=$_POST['Description'];
   $spe=$_POST['Specialite'];
   $photo=$_FILES['img']['name'];

if ($_FILES['img']['error']==0){
   $photo=$_POST['img'];
   $req="select count(*) as total from benevol where photo='$photo'";
   $res= mysqli_query($connect,$req);
   while ($lig=mysqli_fetch_array($res)){
if(($lig['total']==1) and ($photo<>'admin.png'))
unlink("../image/".$photo);}

   $id_benevol=$_POST['id_b'];
   $nom=$_POST['nom'];
   $prenom=$_POST['prenom'];
   $email=$_POST['email'];
   $mot_pass=$_POST['mot_pass'];
   $adresse=$_POST['adresse'];
   $num_tele=$_POST['num_tele'];
   $date_n =$_POST['date_n'];
   $sexe =$_POST['sexe'];
   $description=$_POST['Description'];
   $spe=$_POST['Specialite'];
   $photo=$_FILES['img']['name'];

   copy($_FILES['img']['tmp_name'], "../image/".$_FILES['img']['name']);
   $requete="update benevol set nom_b='$nom',prenom='$prenom',email='$email',mot_pass='$mot_pass',adresse='$adresse',num_tele='$num_tele',date_n='$date_n',sexe='$sexe',photo='$photo',description='$description',Specialite='$spe' where id_benevol='$id_benevol'";
   mysqli_query($connect,$requete);
  
}else

   $requete="update benevol set nom_b='$nom',prenom='$prenom',email='$email',mot_pass='$mot_pass',adresse='$adresse',num_tele='$num_tele',date_n='$date_n',sexe='$sexe',description='$description',Specialite='$spe'  where id_benevol='$id_benevol'";
   mysqli_query($connect,$requete);
   header('location:list table.php');
}

// ______________________________________________________________________________________//

if (isset($_GET['ident_e'])) {
  $id_e=$_GET['ident_e'];
  $ident_e='true';
  $req = "select * from ensginants where id_ensginan ='$id_e'";
  $res = mysqli_query($connect,$req);
  $ligne_e = mysqli_fetch_array($res);
}

if (isset($_POST['botton_e'])) {
   $id_ensginan=$_POST['id_ensginan'];
   $nom=$_POST['nom'];
   $prenom=$_POST['prenom'];
   $num_tele=$_POST['num_tele'];
   $spicialite=$_POST['spicialite'];
   $photo=$_FILES['img']['name'];

if ($_FILES['img']['error']==0){
   $photo=$_POST['img'];
   $req="select count(*) as total from ensginants where photo='$photo'";
   $res= mysqli_query($connect,$req);
   while ($lig=mysqli_fetch_array($res)){
if(($lig['total']==1) and ($photo<>'admin.png'))
unlink("../image/".$photo);}

   $id_ensginan=$_POST['id_ensginan'];
   $nom=$_POST['nom'];
   $prenom=$_POST['prenom'];
   $num_tele=$_POST['num_tele'];
   $spicialite=$_POST['spicialite'];
   $photo=$_FILES['img']['name'];

   copy($_FILES['img']['tmp_name'], "../image/".$_FILES['img']['name']);
   $requete="update ensginants set nom='$nom',prenom='$prenom',num_tele='$num_tele',spicialite='$spicialite',photo='$photo' where id_ensginan='$id_ensginan'";
   mysqli_query($connect,$requete);
  
}else

   $requete="update ensginants set nom='$nom',prenom='$prenom',num_tele='$num_tele',spicialite='$spicialite' where id_ensginan='$id_ensginan'";
   mysqli_query($connect,$requete);
   header('location:list table.php');
}

// ______________________________________________________________________________________//



if (isset($_GET['ident_f'])) {
  $id_f=$_GET['ident_f'];
  $ident_f='true';
  $req = "select * from formations where id_formation ='$id_f'";
  $res = mysqli_query($connect,$req);
  $ligne_f = mysqli_fetch_array($res);
}

if (isset($_POST['botton_f'])) {
   $id_formation=$_POST['id_formation'];
   $nom=$_POST['nom'];
   $date_debut=$_POST['date_debut'];
   $date_fin=$_POST['date_fin'];
   $desscription=$_POST['desscription'];

   $requete="update formations set nom_f='$nom',date_debut='$date_debut',date_fin='$date_fin',desscription='$desscription' where id_formation='$id_formation'";
   mysqli_query($connect,$requete);
   header('location:list table.php');
  
}

// ______________________________________________________________________________________//


if (isset($_GET['ident_a'])) {
  $id_a=$_GET['ident_a'];
  $ident_a='true';
  $req = "select * from adminstrateur where id_admin ='$id_a'";
  $res = mysqli_query($connect,$req);
  $ligne_a = mysqli_fetch_array($res);
}

if (isset($_POST['botton_a'])) {
   $id_admin=$_POST['id_admin'];
   $nom=$_POST['nom'];
   $niveau=$_POST['niveau'];
   $mot_pass=$_POST['mot_pass'];
   $photo=$_FILES['img']['name'];

if ($_FILES['img']['error']==0){
   $photo=$_POST['img'];
   $req="select count(*) as total from adminstrateur where photo='$photo'";
   $res= mysqli_query($connect,$req);
   while ($lig=mysqli_fetch_array($res)){
if(($lig['total']==1) and ($photo<>'admin.png'))
unlink("../image/".$photo);}

   $id_admin=$_POST['id_admin'];
   $nom=$_POST['nom'];
   $niveau=$_POST['niveau'];
   $mot_pass=$_POST['mot_pass'];
   $photo=$_FILES['img']['name'];

   copy($_FILES['img']['tmp_name'], "../image/".$_FILES['img']['name']);
   $requete="update adminstrateur set nom='$nom',niveau='$niveau',mot_pass='$mot_pass',photo='$photo' where id_admin='$id_admin'";
   mysqli_query($connect,$requete);
  
}else

   $requete="update adminstrateur set nom='$nom',niveau='$niveau',mot_pass='$mot_pass' where id_admin='$id_admin'";
   mysqli_query($connect,$requete);
   header('location:list table.php');
}

// ______________________________________________________________________________________//

if(isset($_POST['logout'])) {
  session_destroy();
  header('location:../index.php');
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>update</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->  
  <link rel="icon" type="image/png" href=""/>
<!--===============================================================================================-->
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!--===============================================================================================-->
   <link href="../font awesome/css/all.css" rel="stylesheet">
<!--===============================================================================================-->
    <link href="../style css/animate.css" rel="stylesheet">
<!--===============================================================================================-->
    <link href="../style css/aside-bar.css" rel="stylesheet">
<!--===============================================================================================-->
    <link href="../style css/dashboard.css" rel="stylesheet">
<!--===============================================================================================-->

</head>
<body>

<!-- ________________________________________________________html_____________________________________________________-->

<div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <div class="sidebar-header">
                <h3>EL BADR BLIDA</h3>
            </div>

            <ul class="list-unstyled components">
                <p>menu</p>
                <li class="active">
                    <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">add profil
                    </a>
                    <ul class="collapse list-unstyled" id="homeSubmenu">
                         <li>
                            <a href="add volunteer.php?ident_m=<?php echo 'true'; ?>">add volunteer</a>
                        </li>
                        <li>
                            <a href="add volunteer.php?ident_e=<?php echo 'true'; ?>">add ensignan </a>
                        </li>
                        <li>
                            <a href="add volunteer.php?ident_f=<?php echo 'true'; ?>">add formation </a>
                        </li>
                        <li>
                            <a href="add volunteer.php?ident_a=<?php echo 'true'; ?>">add admin</a>
                        </li>
                        <li>
                          <a href="add volunteer.php?ident_etudier=<?php echo 'true'; ?>">formation etudier</a>
                        </li>
                    </ul>    
                </li>
               <li>
                    <a href="validation.php">validation</a>
                </li>
            
                <li>
                    <a href="statistic.php">statistics</a>
                </li>
                <li>
                    <a href="message_admin.php">Contact</a>
                </li>
            </ul>

            <ul class="list-unstyled CTAs">
                <li>
                    <a href="" class="download">Download source</a>
                </li>
                <li>
                    <a href="" class="article">Back to article</a>
                </li>
            </ul>
        </nav>
<!-- ________________________________________________________html_____________________________________________________-->

        <!-- Page Content  -->
        <div id="content">

            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">

                    <button type="button" id="sidebarCollapse" class="btn btn-info">
                        <i class="fas fa-align-left"></i>
                        <span>update</span>
                    </button>
                    <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fas fa-align-justify"></i>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                       
                         <ul class="nav navbar-nav ml-auto d-lg-none">
                            <li class="nav-item active">
                                <a class="nav-link text-center" href="list table.php">Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-center" href="#">Notifiction</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-center" href="profile admin.php">Profil</a>
                            </li>
                            <li class="nav-item">
                          <form   method="POST"  enctype="multipart/form-data" action="">
                                <a class="dropdown-item" name="logout" href="#"><input class="form-control-plaintext" type="submit" name="logout" value="Log out">
                          </a>
                          </form>
                            </li>
                        </ul>



                      <div class="ml-auto display-nav">
                      <ul class="navbar-nav    ">
                      <li class="nav-item">
                        <a class="nav-link" href="list table.php">
                          <i class="fab fa-buromobelexperte"></i>
                        </a>
                      </li>
                      <li class="nav-item dropdown">
                        <a class="nav-link" href="" id="a" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <i class="fas fa-bell"></i>
                          <span class="notification">5</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="a">
                          <a class="dropdown-item" href="#">Mike John responded to your email</a>
                          <a class="dropdown-item" href="#">You have 5 new tasks</a>
                          <a class="dropdown-item" href="#">You're now friend with Andrew</a>
                          <a class="dropdown-item" href="#">Another Notification</a>
                          <a class="dropdown-item" href="#">Another One</a>
                        </div>
                      </li>
                      <li class="nav-item dropdown">
                        <a class="nav-link" href="" id="navbarDropdownProfile" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                         <i class="fas fa-user"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownProfile">
                          <a class="dropdown-item" href="Profile admin.php">Profile</a>
                          <a class="dropdown-item" href="#">Settings</a>
                          <div class="dropdown-divider"></div>
                          <form   method="POST"  enctype="multipart/form-data" action="">
                          <a class="dropdown-item" name="logout" href="#"><input class="form-control-plaintext" type="submit" name="logout" value="Log out">
                          </a>
                          </form>
                        </div>
                      </li>
                    </ul>
                  </div>

               </div>
            </div>
        </nav>
<!-- ______________________________________________________benevol_____________________________________________________-->



<div class="content">
        <div class="container">
          <?php if ($ident_m =='true') {  ?>
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Edit Profile Benevol</h4>
                  <p class="card-category">Complete your profile</p>
                </div>
                <div class="card-body">
                  <form   method="POST"  enctype="multipart/form-data" action="">
                    <div class="row">
                      <div class="col-md-5">
                        <div class="form-group">
                          <input type="hidden" name="id_b" value="<?php echo($ligne['id_benevol']);?>">
                          <input type="hidden" name="img" value="<?php echo($ligne['photo']);?>" >
                          <label class="bmd-label-floating">First Name</label>
                          <input type="text" class="form-control" name="nom" value="<?php echo($ligne['nom_b']);?>">
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Last Name</label>
                          <input type="text" class="form-control" name="prenom" value="<?php echo($ligne['prenom']);?>">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Email address</label>
                          <input type="email" class="form-control" name="email" value="<?php echo($ligne['email']);?>">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Password</label>
                          <input type="text" class="form-control" name="mot_pass" value="<?php echo($ligne['mot_pass']);?>">
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Birth Day</label>
                          <input type="Date" class="form-control" name="date_n" value="<?php echo($ligne['date_n']);?>">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-8">
                        <div class="form-group">
                          <label class="bmd-label-floating">Adress</label>
                          <input type="text" class="form-control" name="adresse" value="<?php echo($ligne['adresse']);?>">
                        </div>
                      </div>
                       <div class="col-md-4">
                        <label class="bmd-label-floating">image</label>
                         <div class="form-group custom-file">
                          <input type="file" class="custom-file-input" name="img" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
                          <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                         </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Number Phone</label>
                          <input type="tel" class="form-control" name="num_tele" value="<?php echo($ligne['num_tele']);?>">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Sexe</label>
                          <select class="form-control" name="sexe">
                            <option value="<?php echo($ligne['sexe']);?>" ><?php echo($ligne['sexe']);?></option>
                            <option value="Homme">Homme</option>
                            <option value="Femme">Femme</option>
                            <option value="autre">autre</option>
                        </select>
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Specialite</label>
                          <select class="form-control" name="Specialite">
                            <option value="<?php echo($ligne['specialite']);?>" ><?php echo($ligne['specialite']);?></option>
                            <option value="Specialist medicine">Specialist Medicine</option>
                            <option value="General Medicine">General Medicine</option>
                            <option value="dentist">Dentist</option>
                            <option value="other">Other</option>
                        </select>                        
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <label>About Me</label>
                          <div class="form-group">
                            <label class="bmd-label-floating"> Lamborghini Mercy, Your chick she so thirsty, I'm in that two seat Lambo.</label>
                            <textarea class="form-control" rows="5" name="Description"><?php echo($ligne['description']);?></textarea>
                          </div>
                        </div>
                      </div>
                    </div>
                   <a href=""><button  type="submit" name="botton_b" class="btn btn-primary pull-right">Update Profile
                   </button></a>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
             </div>
            </div>
          <?php } ?>
      <!-- form 1 -->
            
      <!-- form 2 -->
       <?php if ($ident_e =='true') {  ?>
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Edit Profile Ensnigana</h4>
                  <p class="card-category">Complete your profile</p>
                </div>
                <div class="card-body">
                  <form   method="POST"  enctype="multipart/form-data" action="">
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <input type="hidden" name="id_ensginan" value="<?php echo($ligne_e['id_ensginan']);?>">
                          <input type="hidden" name="img" value="<?php echo($ligne_e['photo']);?>" >
                          <label class="bmd-label-floating">First Name</label>
                          <input type="text" class="form-control" name="nom" value="<?php echo($ligne_e['nom']);?>">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Last Name</label>
                          <input type="text" class="form-control" name="prenom" value="<?php echo($ligne_e['prenom']);?>">
                        </div>
                      </div>
                      
                       <div class="col-md-4">
                        <label class="bmd-label-floating">image</label>
                         <div class="form-group custom-file">
                          <input type="file" class="custom-file-input" name="img" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
                          <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                         </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Number Phone</label>
                          <input type="tel" class="form-control" name="num_tele" value="<?php echo($ligne_e['num_tele']);?>">
                        </div>
                      </div>
                       <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Spicialite</label>
                          <input type="text" class="form-control" name="spicialite" value="<?php echo($ligne_e['spicialite']);?>">
                        </div>
                      </div>
                 
                    </div>
                   <a href=""><button  type="submit" name="botton_e" class="btn btn-primary pull-right">Update Profile
                   </button></a>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
             </div>
            </div>
            <?php } ?>
      <!-- form 2 -->
            
      <!-- form 3 -->
       <?php if ($ident_f =='true') {  ?>
      <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Edit Profile Formation</h4>
                  <p class="card-category">Complete your profile</p>
                </div>
                <div class="card-body">
                  <form   method="POST"  enctype="multipart/form-data" action="">
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <input type="hidden" name="id_formation" value="<?php echo($ligne_f['id_formation']);?>">
                          <label class="bmd-label-floating">Name</label>
                          <input type="text" class="form-control" name="nom" value="<?php echo($ligne_f['nom_f']);?>">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">date_debut</label>
                          <input type="date" class="form-control" name="date_debut" value="<?php echo($ligne_f['date_debut']);?>">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">date_fin</label>
                          <input type="date" class="form-control" name="date_fin" value="<?php echo($ligne_f['date_fin']);?>">
                        </div>
                      </div>
                       <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">desscription</label>
                          <input type="text" class="form-control" name="desscription" value="<?php echo($ligne_f['desscription']);?>">
                        </div>
                      </div>
                 
                    </div>
                   <a href=""><button  type="submit" name="botton_f" class="btn btn-primary pull-right">Update Profile
                   </button></a>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
             </div>
            </div>
            <?php } ?>
      <!-- form 3 -->
      <!-- form 4 -->
       <?php if ($ident_a =='true') {  ?>
      <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Edit Profile Admin</h4>
                  <p class="card-category">Complete your profile</p>
                </div>
                <div class="card-body">
                  <form   method="POST"  enctype="multipart/form-data" action="">
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <input type="hidden" name="id_admin" value="<?php echo($ligne_a['id_admin']);?>">
                          <input type="hidden" name="img" value="<?php echo($ligne_a['photo']);?>" >
                          <label class="bmd-label-floating">First Name</label>
                          <input type="text" class="form-control" name="nom" value="<?php echo($ligne_a['nom']);?>">
                        </div>
                      </div>
                       <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">niveau</label>
                          <select class="form-control" name="niveau">
                            <option value="<?php echo($ligne_a['niveau']);?>" ><?php echo($ligne_a['niveau']);?></option>
                            <option value="editeur">editeur</option>
                            <option value="moderateur">moderateur</option>
                            <option value="analyst">analyst</option>
                            <option value="admin">admin</option>
                        </select>
                        </div>
                      </div>
                       <div class="col-md-4">
                        <label class="bmd-label-floating">image</label>
                         <div class="form-group custom-file">
                          <input type="file" class="custom-file-input" name="img" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
                          <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                         </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Password</label>
                          <input type="tel" class="form-control" name="mot_pass" value="<?php echo($ligne_a['mot_pass']);?>">
                        </div>
                      </div>
    
                    </div>
                   <a href=""><button  type="submit" name="botton_a" class="btn btn-primary pull-right">Update Profile
                   </button></a>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
             </div>
            </div>
            <?php } ?>
      <!-- form 4 -->

          </div>
        </div>



<!-- ________________________________________________________wrapper_____________________________________________________-->
        </div>
    </div>
<!-- ________________________________________________________html_____________________________________________________-->

	


<!--===============================================================================================-->
  <script src="../jQuery/sildebare js/jQuery v3.3.1.js"></script>
<!--===============================================================================================-->
 <script src="../jQuery/sildebare js/jquery mCustomScrollbar .min.js"></script>
<!--===============================================================================================-->
  <script src="../jQuery/popper.min.js"></script>
<!--===============================================================================================-->
  <script src="../bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
    <script>
        $(document).ready(function () {
            $("#sidebar").mCustomScrollbar({
                theme: "minimal"
            });

            $('#sidebarCollapse').on('click', function () {
                $('#sidebar, #content').toggleClass('active');
                $('.collapse.in').toggleClass('in');
                $('a[aria-expanded=true]').attr('aria-expanded', 'false');
            });
        });

    </script>
</body>
</html>