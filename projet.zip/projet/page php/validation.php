<?php 
session_start();
require_once("connection.php");

$id_admin= $_SESSION['id_admin']=1;
  
if (isset($_POST['valide'])) {
   $id_benevol=$_POST['id_b'];
   $valid=$_POST['oui_non'];
   $requete="update benevol set validation='$valid' where id_benevol='$id_benevol'";
   mysqli_query($connect,$requete);
   header('location:validation.php');
}

if (isset($_POST['valide_f'])) {
   $id_benevol=$_POST['id_b'];
   $valid=$_POST['oui_non'];
   $requete="update inscription set valider='$valid' where id_benevol='$id_benevol'";
   mysqli_query($connect,$requete);
   header('location:validation.php');
}

if(isset($_POST['logout'])) {
  session_destroy();
  header('location:../index.php');
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>validation</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->  
  <link rel="icon" type="image/png" href=""/>
<!--===============================================================================================-->
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!--===============================================================================================-->
   <link href="../font awesome/css/all.css" rel="stylesheet">
<!--===============================================================================================-->
    <link href="../style css/animate.css" rel="stylesheet">
<!--===============================================================================================-->
    <link href="../style css/aside-bar.css" rel="stylesheet">
<!--===============================================================================================-->
    <link href="../style css/dashboard.css" rel="stylesheet">
<!--===============================================================================================-->

</head>
<body>

<!-- ________________________________________________________html_____________________________________________________-->

<div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <div class="sidebar-header">
                <h3>EL BADR BLIDA</h3>
            </div>

            <ul class="list-unstyled components">
                <p>menu</p>
                <li class="active">
                    <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">add profil
                    </a>
                    <ul class="collapse list-unstyled" id="homeSubmenu">
                         <li>
                            <a href="add volunteer.php?ident_m=<?php echo 'true'; ?>">add volunteer</a>
                        </li>
                        <li>
                            <a href="add volunteer.php?ident_e=<?php echo 'true'; ?>">add ensignan </a>
                        </li>
                        <li>
                            <a href="add volunteer.php?ident_f=<?php echo 'true'; ?>">add formation </a>
                        </li>
                        <li>
                            <a href="add volunteer.php?ident_a=<?php echo 'true'; ?>">add admin</a>
                        </li>
                        <li>
                          <a href="add volunteer.php?ident_etudier=<?php echo 'true'; ?>">formation etudier</a>
                        </li>
                    </ul>    
                </li>
              <li>
                    <a href="validation.php">validation</a>
                </li>
            
                <li>
                    <a href="statistic.php">statistics</a>
                </li>
                <li>
                    <a href="message_admin.php">Contact</a>
                </li>
            </ul>

            <ul class="list-unstyled CTAs">
                <li>
                    <a href="" class="download">Download source</a>
                </li>
                <li>
                    <a href="" class="article">Back to article</a>
                </li>
            </ul>
        </nav>
<!-- ________________________________________________________html_____________________________________________________-->

        <!-- Page Content  -->
        <div id="content">

            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">

                    <button type="button" id="sidebarCollapse" class="btn btn-info">
                        <i class="fas fa-align-left"></i>
                        <span>show data base</span>
                    </button>
                    <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fas fa-align-justify"></i>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                       
                         <ul class="nav navbar-nav ml-auto d-lg-none">
                            <li class="nav-item active">
                                <a class="nav-link text-center" href="list table.php">Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-center" href="#">Notifiction</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-center" href="profile admin.php">Profil</a>
                            </li>
                            <li class="nav-item">
                          <form   method="POST"  enctype="multipart/form-data" action="">
                                <a class="dropdown-item" name="logout" href="#"><input class="form-control-plaintext" type="submit" name="logout" value="Log out">
                          </a>
                          </form>
                            </li>
                        </ul>



                      <div class="ml-auto display-nav">
                      <ul class="navbar-nav    ">
                      <li class="nav-item">
                        <a class="nav-link" href="list table.php">
                          <i class="fab fa-buromobelexperte"></i>
                        </a>
                      </li>
                      <li class="nav-item dropdown">
                        <a class="nav-link" href="" id="a" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <i class="fas fa-bell"></i>
                          <span class="notification">5</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="a">
                          <a class="dropdown-item" href="#">Mike John responded to your email</a>
                          <a class="dropdown-item" href="#">You have 5 new tasks</a>
                          <a class="dropdown-item" href="#">You're now friend with Andrew</a>
                          <a class="dropdown-item" href="#">Another Notification</a>
                          <a class="dropdown-item" href="#">Another One</a>
                        </div>
                      </li>
                      <li class="nav-item dropdown">
                        <a class="nav-link" href="" id="navbarDropdownProfile" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                         <i class="fas fa-user"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownProfile">
                          <a class="dropdown-item" href="Profile admin.php">Profile</a>
                          <a class="dropdown-item" href="#">Settings</a>
                          <div class="dropdown-divider"></div>
                          <form   method="POST"  enctype="multipart/form-data" action="">
                          <a class="dropdown-item" name="logout" href="#"><input class="form-control-plaintext" type="submit" name="logout" value="Log out">
                          </a>
                          </form>
                        </div>
                      </li>
                    </ul>
                  </div>

               </div>
            </div>
        </nav>
<!-- ________________________________________________________html_____________________________________________________-->
      
              <div class="container-fluid">
                <div class="row">
                  <div class="col-md-12">
                    <div class="card">
                      <div class="card-header card-header-primary">
                        <h4 class="card-title "> Table validation benevol</h4>
                        <p class="card-category"> Here is a subtitle for this table</p>
                      </div>
                      <div class="card-body">
                        <div class="table-responsive">
                          <table class="table">
                            <thead class=" text-primary">
                            <th>photo</th><th>id</th> <th>nom</th> <th>prenom</th> <th>valide</th>
                            </thead>
                            <?php $ex= mysqli_query ($connect,'select * from benevol '); ?>
                            <?php while ($ligne = mysqli_fetch_array($ex)) { ?>
                            <tbody>
                              <tr>
                                <td><img src="../image/<?php echo ($ligne['photo']);  ?>" width="60px" height="60px" /></td>
                                <td><?php echo($ligne['id_benevol']);?></td> 
                                <td><?php echo($ligne['nom_b']);?></td> 
                                <td><?php echo($ligne['prenom']);?></td> 
                                <td><?php echo($ligne['validation']);?></td>
                                <form   method="POST"  enctype="multipart/form-data" action="">
                                <td>
                                <select class="" name="oui_non">
                                    <option value="oui">oui</option>
                                    <option value="non">non</option>
                                </select>
                                <input class="btn btn-primary" type="submit" name="valide"> 
                                </td>
                                <td><input type="hidden" name="id_b" value="<?php echo($ligne['id_benevol']);?>"></td>
                                </form>
                              </tr>
                              <?php } ?>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
               </div>
                <br>
                <!--  spaice btwen tables  -->
                <br>
                <div class="row">
                  <div class="col-md-12">
                    <div class="card">
                      <div class="card-header card-header-primary">
                        <h4 class="card-title ">Table validation inscription</h4>
                        <p class="card-category"> Here is a subtitle for this table</p>
                      </div>
                      <div class="card-body">
                        <div class="table-responsive">
                          <table class="table">
                            <thead class=" text-primary">
                            <th>id_benevol</th><th>nom benevol</th><th>id_formation</th> <th>nom formation</th> <th>date</th><th>validire</th> 
                            </thead>
                            <?php $ex= mysqli_query ($connect,'
                              select *  from benevol
                                join inscription
                                  on benevol.id_benevol=inscription.id_benevol
                                join formations
                                  on inscription.id_formation_in=formations.id_formation '); ?>
                            <?php while ($ligne = mysqli_fetch_array($ex)) { ?>
                            <tbody>
                              <tr>
                                <td><?php echo($ligne['id_benevol']);?></td> 
                                <td><?php echo($ligne['nom_b']);?></td>
                                <td><?php echo($ligne['id_formation_in']);?></td>
                                <td><?php echo($ligne['nom_f']);?></td>
                                <td><?php echo($ligne['date_insc']);?></td>
                                <td><?php echo($ligne['valider']);?></td>
                                <form   method="POST"  enctype="multipart/form-data" action="">
                                <td>
                                <select class="" name="oui_non">
                                    <option value="oui">oui</option>
                                    <option value="non">non</option>
                                </select>
                                <input class="btn btn-primary" type="submit" name="valide_f"> 
                                </td>
                                <td>
                                  <input type="hidden" name="id_b" value="<?php echo($ligne['id_benevol']);?>">
                                </td>
                                </form> 
                              </tr>
                              <?php } ?>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>


<!-- ________________________________________________________wrapper_____________________________________________________-->
        </div>
    </div>
<!-- ________________________________________________________html_____________________________________________________-->

	


<!--===============================================================================================-->
  <script src="../jQuery/sildebare js/jQuery v3.3.1.js"></script>
<!--===============================================================================================-->
 <script src="../jQuery/sildebare js/jquery mCustomScrollbar .min.js"></script>
<!--===============================================================================================-->
  <script src="../jQuery/popper.min.js"></script>
<!--===============================================================================================-->
  <script src="../bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
    <script>
        $(document).ready(function () {
            $("#sidebar").mCustomScrollbar({
                theme: "minimal"
            });

            $('#sidebarCollapse').on('click', function () {
                $('#sidebar, #content').toggleClass('active');
                $('.collapse.in').toggleClass('in');
                $('a[aria-expanded=true]').attr('aria-expanded', 'false');
            });
        });

    </script>
</body>
</html>