<?php 
session_start();


require_once("connection.php");
$id_admin= $_SESSION['id_admin']=1;


  $date= date("y/m/d  h/i/s");

if (isset($_POST['send'])) {
  $id_admin;
  $date;
  $content=$_POST['content'];
  $req="insert into message_admin (date,content,id_admin) values ('$date','$content','$id_admin')";
  mysqli_query($connect,$req);
}
// start create file of extation .exl

if(isset($_POST['logout'])) {
  session_destroy();
  header('location:../index.php');
}


?>
<!-- ________________________________________________________html_____________________________________________________-->



<!DOCTYPE html>
<html lang="en">

<head>
  <title>admin message</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->  
  <link rel="icon" type="image/png" href=""/>
<!--===============================================================================================-->
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!--===============================================================================================-->
   <link href="../font awesome/css/all.css" rel="stylesheet">
<!--===============================================================================================-->
    <link href="../style css/animate.css" rel="stylesheet">
<!--===============================================================================================-->
    <link href="../style css/aside-bar.css" rel="stylesheet">
<!--===============================================================================================-->
    <link href="../style css/dashboard.css" rel="stylesheet">
<!--===============================================================================================-->
    <link href="../style css/message.css" rel="stylesheet">
<!--===============================================================================================-->

</head>
<body>

<!-- ________________________________________________________html_____________________________________________________-->

<div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <div class="sidebar-header">
                <h3>EL BADR BLIDA</h3>
            </div>

            <ul class="list-unstyled components">
                <p>menu</p>
                <li class="active">
                    <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">add profil
                    </a>
                    <ul class="collapse list-unstyled" id="homeSubmenu">
                         <li>
                            <a href="add volunteer.php?ident_m=<?php echo 'true'; ?>">add volunteer</a>
                        </li>
                        <li>
                            <a href="add volunteer.php?ident_e=<?php echo 'true'; ?>">add ensignan </a>
                        </li>
                        <li>
                            <a href="add volunteer.php?ident_f=<?php echo 'true'; ?>">add formation </a>
                        </li>
                        <li>
                            <a href="add volunteer.php?ident_a=<?php echo 'true'; ?>">add admin</a>
                        </li>
                        <li>
                          <a href="add volunteer.php?ident_etudier=<?php echo 'true'; ?>">formation etudier</a>
                        </li>
                    </ul>    
                </li>
               <li>
                    <a href="validation.php">validation</a>
                </li>
            
                <li>
                    <a href="statistic.php">statistics</a>
                </li>
                <li>
                    <a href="message_admin.php">Contact</a>
                </li>
            </ul>

            <ul class="list-unstyled CTAs">
                <li>
                    <a href="" class="download">Download source</a>
                </li>
                <li>
                    <a href="" class="article">Back to article</a>
                </li>
            </ul>
        </nav>
<!-- ________________________________________________________html_____________________________________________________-->

        <!-- Page Content  -->
        <div id="content">

            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">

                    <button type="button" id="sidebarCollapse" class="btn btn-info">
                        <i class="fas fa-align-left"></i>
                        <span>show data base</span>
                    </button>
                    <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fas fa-align-justify"></i>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                       
                           <ul class="nav navbar-nav ml-auto d-lg-none">
                            <li class="nav-item active">
                                <a class="nav-link text-center" href="list table.php">Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-center" href="#">Notifiction</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-center" href="profile admin.php">Profil</a>
                            </li>
                            <li class="nav-item">
                          <form   method="POST"  enctype="multipart/form-data" action="">
                                <a class="dropdown-item" name="logout" href="#"><input class="form-control-plaintext" type="submit" name="logout" value="Log out">
                          </a>
                          </form>
                            </li>
                        </ul>



                      <div class="ml-auto display-nav">
                      <ul class="navbar-nav    ">
                      <li class="nav-item">
                        <a class="nav-link" href="list table.php">
                          <i class="fab fa-buromobelexperte"></i>
                        </a>
                      </li>
                      <li class="nav-item dropdown">
                        <a class="nav-link" href="" id="a" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <i class="fas fa-bell"></i>
                          <span class="notification">5</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="a">
                          <a class="dropdown-item" href="#">Mike John responded to your email</a>
                          <a class="dropdown-item" href="#">You have 5 new tasks</a>
                          <a class="dropdown-item" href="#">You're now friend with Andrew</a>
                          <a class="dropdown-item" href="#">Another Notification</a>
                          <a class="dropdown-item" href="#">Another One</a>
                        </div>
                      </li>
                      <li class="nav-item dropdown">
                        <a class="nav-link" href="" id="navbarDropdownProfile" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                         <i class="fas fa-user"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownProfile">
                          <a class="dropdown-item" href="Profile admin.php">Profile</a>
                          <a class="dropdown-item" href="#">Settings</a>
                          <div class="dropdown-divider"></div>
                          <form   method="POST"  enctype="multipart/form-data" action="">
                          <a class="dropdown-item" name="logout" href="#"><input class="form-control-plaintext" type="submit" name="logout" value="Log out">
                          </a>
                          </form>
                        </div>
                      </li>
                    </ul>
                  </div>

                     


                    </div>
                </div>
            </nav>
<!-- ________________________________________________________html_____________________________________________________-->

    <div class="content">
              <div class="container-fluid">
                <div class="row">
                  <div class="col-md-12">
                   
                  <div class="card">
                  <div class="card-header">
                      <h3 class="card-title">message</h3>
                      <p class="card-category"> your message form benevol</p>
                  </div>
                    <div class="body">
     <?php  $ex= mysqli_query ($connect,'select * from message_b join benevol on message_b.id_benevol=benevol.id_benevol '); 
      while ($ligne_m = mysqli_fetch_array($ex)) {
                        ?>
                        <div class="message-view">
                        <h3><?php  echo ($ligne_m['nom_b']) ;?></h3>
                        <small><?php  echo ($ligne_m['date']) ;?></small>
                        <p class="col-md-11 mt-2 border"><?php  echo ($ligne_m['content']) ;?></p>
                        </div>
      <?php  } ?>
                    </div>
                  </div>
                </div>
              </div>

              <br>

                  <div class="row">
                    <div class="col-md-12">
                      <div class="card">
                  <div class="card-header">
                      <h3 class="card-title">message</h3>
                      <p class="card-category">right your message for admin</p>
                  </div>
                    <div class="body">
                      <form method="POST">
                        <div class="container-fluid message">
                        <textarea class="col-md-12 mt-2 " name="content"></textarea>
                        <button class="btn btn-success" name="send">send</button> 
                        </div>
                      </form>
                    </div>
                  </div>
                    </div>
                  </div>


<!-- ________________________________________________________wrapper_____________________________________________________-->
        </div>
    </div>
<!-- ________________________________________________________html_____________________________________________________-->

	


<!--===============================================================================================-->
  <script src="../jQuery/sildebare js/jQuery v3.3.1.js"></script>
<!--===============================================================================================-->
 <script src="../jQuery/sildebare js/jquery mCustomScrollbar .min.js"></script>
<!--===============================================================================================-->
  <script src="../jQuery/popper.min.js"></script>
<!--===============================================================================================-->
  <script src="../bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
    <script>
        $(document).ready(function () {
            $("#sidebar").mCustomScrollbar({
                theme: "minimal"
            });

            $('#sidebarCollapse').on('click', function () {
                $('#sidebar, #content').toggleClass('active');
                $('.collapse.in').toggleClass('in');
                $('a[aria-expanded=true]').attr('aria-expanded', 'false');
            });
        });

    </script>
</body>
</html>