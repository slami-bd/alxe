<?php
$connect = mysqli_connect ('127.0.0.1','root','','exemple01') or die ('database not connect');

?>