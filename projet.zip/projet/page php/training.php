<?php 
session_start();
require_once("connection.php");
$id_bn=$_SESSION['id_benevol'];
$req = "select * from benevol where id_benevol ='$id_bn'";
$res = mysqli_query($connect,$req);
$ligne = mysqli_fetch_array($res);

$req_1="select * from inscription ";
$res_1 = mysqli_query($connect,$req_1);

  



if(isset($_POST['botton_insc'])) {
 $date_insc=$_POST['date_insc'];

   
  foreach ($_POST['ff'] as $key ) {
   
       $id_formation=$key;
       $requet="insert into inscription (id_benevol,id_formation_in,date_insc) values ('$id_bn','$id_formation','$date_insc')";
       mysqli_query($connect,$requet);
           
  } 
  }

if(isset($_POST['logout'])) {
  session_destroy();
  header('location:../index.php');
}

 ?> 
<!DOCTYPE html>
<html lang="en">

<head>
  <title>training</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->  
  <link rel="icon" type="image/png" href=""/>
<!--===============================================================================================-->
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!--===============================================================================================-->
    <link href="../style css/animate.css" rel="stylesheet">
<!--===============================================================================================-->
    <link href="../style css/training.css" rel="stylesheet">
<!--===============================================================================================-->
</head>
<body>
	
	
<!-- start nav bar  -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">profile</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class=" navbar-collapse" >
    <ul class="navbar-nav ml-auto">
      <span class="border d-none d-lg-block"></span>
      <li class="nav-item dropdown">
        <a class="nav-link d-md-none d-lg-block" href="#" id="a" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <img src="../image/<?php echo ($ligne['photo']);?>" class="d-none d-lg-block rounded-pill ml-5" width="55px" height="55px">
        </a>
        <div class="collapse dropdown-menu text-center" aria-labelledby="a" id="navbarSupportedContent">
          <a class="dropdown-item" href="profil.php">profile</a>
          <a class="dropdown-item" href="Edit Profil.php">Edite </a>
          <a class="dropdown-item" href="training.php">training</a>
          <a class="dropdown-item" href="message.php">message </a>
          <div class="dropdown-divider"></div>
          <form   method="POST"  enctype="multipart/form-data" action="">
          <a class="dropdown-item" name="logout" href="#"><input class="form-control-plaintext" type="submit" name="logout" 
            value="Log out">
          </a>
          </form>
        </div>
      </li>
      <li class="mt-4 d-none d-lg-block"><span class="ml-3"><?php echo($ligne['nom_b']);?></span></li>
      <li class="mt-4 d-none d-lg-block"><span class="ml-3"><?php echo($ligne['prenom']);?></span></li>
      <span class="border-icon d-none d-lg-block"></span>
      <li class="mt-4 d-none d-lg-block"><a href="" class="ml-4 mr-4"><i class="fas fa-bell"></i></a></li>
      <span class="border d-none d-lg-block"></span>
    </ul>
    
  </div>
</nav><br>
<!-- end  nav bar  -->

<!--  Start body  -->
<div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title ">Training Available</h4>
                  <p class="card-category"> Choose the training you want </p>
                </div>
                <div class="card-body">
                  <div class="table-responsive">
                    <form  method="POST" enctype="multipart/form-data" action="">
                    <table class="table">
                      <thead class=" text-primary">
                        <th>ID</th><th>Name</th><th>Date Start</th><th>Date End</th><th>Description</th>
                      </thead>
                       <?php $date=date("Y/m/d");
                        $ex2= mysqli_query ($connect,"select * from formations ");
                        $a=0;
                        while ($ligne3= mysqli_fetch_array($ex2)){ ?>  
                      <tbody>

                        <tr>
                          <td>
                            <input type="checkbox" name="ff[]" value="<?php echo($ligne3['id_formation']);?>"  >
                          </td>
                          <td>
                            <input  type="hidden" name="date_insc" value="<?php echo $date ;?>">
                            <?php echo($ligne3['nom_f']);?>
                          </td>
                          <td>
                            <?php echo($ligne3['date_debut']);?>
                          </td>
                          <td>
                            <?php echo($ligne3['date_fin']);?>
                          </td>
                          <td class="text-primary">
                            <?php echo($ligne3['desscription']);?>
                          </td>
                        </tr>
                      </tbody>
                      <?php } ?>
                    </table>
                  </div>
                </div>
                 <div class="btn btn-defult pull-right"><a href="" ><input type="submit" class="btn btn-primary pull-right" name="botton_insc" value="Update Training"></a></div>
                 <div class="clearfix"></div>
              </div>
              </form>
            </div>
          </div>
        </div>
      </div>
<!--  Start body  -->
  <br>
              <div class="container-fluid">
                <div class="row">
                  <div class="col-md-12">
                    <div class="card">
                      <div class="card-header card-header-primary">
                        <h4 class="card-title ">Table Training </h4>
                        <p class="card-category"> The exercises you have chosen</p>
                      </div>
                      <div class="card-body">
                        <div class="table-responsive">
                          <table class="table">
                            <thead class=" text-primary">
                            <th>id benevol</th><th>nom fromation</th><th>id_formation</th> <th>date_insc</th> <th>valider</th> 
                            </thead>
                            <?php $ex= mysqli_query ($connect,"
                              select *
                               from inscription join formations 
                              on inscription.id_formation_in=formations.id_formation 
                            where inscription.id_benevol='$id_bn'"
                            ); ?>
                            <?php while ($ligne = mysqli_fetch_array($ex)) { ?>
                            <tbody>
                              <tr>
                                <td><?php echo($ligne['id_benevol']);?></td>
                                <td><?php echo($ligne['nom_f']);?></td> 
                                <td><?php echo($ligne['id_formation_in']);?></td> 
                                <td><?php echo($ligne['date_insc']);?></td>
                                <td><?php echo($ligne['valider']);?></td>
                              </tr>
                              <?php } ?>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

<!--===============================================================================================-->
  <script src="../jQuery/jquery-3.4.1.min.js"></script>
<!--===============================================================================================-->
  <script src="../jQuery/popper.min.js"></script>
<!--===============================================================================================-->
  <script src="../bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->

</body> 
<!-- Start footer -->

<footer class="footer"><hr>
        <div class="container-fluid">
          <nav class="float-left">
            <ul class="ul-footer " >
              <li >
                <a href="https://www.creative-tim.com">
                  Creative Tim
                </a>
              </li>
              <li>
                <a href="https://creative-tim.com/presentation">
                  About Us
                </a>
              </li>
              <li>
                <a href="http://blog.creative-tim.com">
                  Blog
                </a>
              </li>
              <li>
                <a href="https://www.creative-tim.com/license">
                  Licenses
                </a>
              </li>
            </ul>
          </nav>
          <div class="copyright float-right">
            &copy;
            <script>
              document.write(new Date().getFullYear())
            </script>, made with <i class="material-icons">favorite</i> by
            <a href="https://www.creative-tim.com" target="_blank">Creative Tim</a> for a better web.
          </div>
        </div>
      </footer>
<!-- Start footer -->
	
</html>