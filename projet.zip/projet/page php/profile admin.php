<?php
session_start();


require_once("connection.php");

if(isset($_POST['logout'])) {
  session_destroy();
  header('location:../index.php');
}
 $id_admin=$_SESSION['id_admin'];

$ex= mysqli_query ($connect,"select * from adminstrateur where id_admin='$id_admin'");
while ($ligne = mysqli_fetch_array($ex)){ 

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>profil admin</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->  
  <link rel="icon" type="image/png" href=""/>
<!--===============================================================================================-->
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!--===============================================================================================-->
    <link href="../style css/animate.css" rel="stylesheet">
<!--===============================================================================================-->
    <link href="../style css/signup.css" rel="stylesheet">
<!--===============================================================================================-->
</head>
<body>
	
	
<!-- start nav bar  -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="btn btn-round btn-fill btn-info" href="list table.php">Home</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class=" navbar-collapse" >
    <ul class="navbar-nav ml-auto">
      <span class="border d-none d-lg-block"></span>
      <li class="nav-item dropdown">
        <a class="nav-link d-md-none d-lg-block" href="#" id="a" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <img src="../image/<?php echo ($ligne['photo']);?>" class="d-none d-lg-block rounded-pill ml-5" width="55px" height="55px">
        </a>
        <div class="dropdown-menu text-center" aria-labelledby="a" id="navbarSupportedContent">
          <a class="dropdown-item" href="">Edite </a>
          <a class="dropdown-item" href="">anther</a>
          <div class="dropdown-divider"></div>
          <form   method="POST"  enctype="multipart/form-data" action="">
          <a class="dropdown-item" name="logout" href="#"><input class="form-control-plaintext" type="submit" name="logout" 
            value="Log out">
          </a>
          </form>
        </div>
      </li>
      <li class="mt-4 d-none d-lg-block"><span class="ml-3"><?php echo($ligne['nom']);?></span></li>
      <span class="border-icon d-none d-lg-block"></span>
      <li class="mt-4 d-none d-lg-block"><span class="ml-3"><?php echo($ligne['niveau']);?></span></li>
      <li class="mt-4 d-none d-lg-block"><a href="" class="ml-4 mr-4">  </a></li>
      <span class="border d-none d-lg-block"></span>
    </ul>
  	
  </div>
</nav>
<!-- end  nav bar  -->
	<br>
<!--  Start body  -->
    <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-8 ml-auto mr-auto">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Admin Information</h4>
                  <p class="card-category">Are you looking for more components? </p>
                </div>
                <div class="card-body">
                  <div class="table-responsive table-upgrade">
                   
                    <table class="table">
                      <thead>
                        <tr>
                          <th>Information</th>
                          <th class="text-center"></th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>Name</td>
                          <td class="text-center"><?php echo($ligne['nom']);?></i></td>
                        </tr>
                        <tr>
                          <td>niveau</td>
                          <td class="text-center"><?php echo($ligne['niveau']);?></i></td>
                        </tr>
                        <tr>
                          <td>Password</td>
                          <td class="text-center"><?php echo($ligne['mot_pass']);?></td>
                        </tr>
                        
                        <tr>
                          <td class="text-center"></td>
                          <td class="text-center">
                            <a target="" href="list table.php" class="btn btn-round btn-fill btn-info">ok</a>
                          </td>
                        </tr>
                      </tbody>
                    
                    </table>
                  </div>
                </div>
              </div>
            </div>
                <div class="col-md-4">
              <div class="card card-profile">
                <div class="card-avatar">
                  <a href="#pablo">
                    <img class="img-fluid" src="../image/<?php echo($ligne['photo']);?>" width="400"
                    height="400"/>
                  </a>
                </div>
                <div class="card-body">
                  <h6 class="card-category text-gray">CEO / Co-Founder</h6>
                  <h4 class="card-title"><?php echo($ligne['nom']);?> <?php echo($ligne['niveau']);?></h4>
                </div>
              </div>
          </div>
        </div>
      </div>
<?php } ?>
<!--  Start body  -->

<!--===============================================================================================-->
  <script src="../jQuery/jquery-3.4.1.min.js"></script>
<!--===============================================================================================-->
  <script src="../jQuery/popper.min.js"></script>
<!--===============================================================================================-->
  <script src="../bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->

</body>

	
</html>