<?php
session_start();
require_once("connection.php");

  $id_bn=$_SESSION['id_benevol'];
  $req = "select * from benevol where id_benevol ='$id_bn' ";
  $res = mysqli_query($connect,$req);
  $ligne = mysqli_fetch_array($res);

if (isset($_POST['botton'])) {
   $id_benevol=$_POST['id_b'];
   $nom=$_POST['nom_b'];
   $prenom=$_POST['prenom'];
   $email=$_POST['email'];
   $mot_pass=$_POST['mot_pass'];
   $adresse=$_POST['adresse'];
   $num_tele=$_POST['num_tele'];
   $date_n =$_POST['date_n'];
   $sexe =$_POST['sexe'];
   $description=$_POST['Description'];
   $spe=$_POST['Specialite'];
   $photo=$_FILES['img']['name'];

if ($_FILES['img']['error']==0){
   $photo=$_POST['img'];
   $req="select count(*) as total from benevol where photo='$photo'";
   $res= mysqli_query($connect,$req);
   while ($lig=mysqli_fetch_array($res)){
if(($lig['total']==1) and ($photo<>'admin.png'))
unlink("../image/".$photo);}

   $id_benevol=$_POST['id_b'];
   $nom=$_POST['nom_b'];
   $prenom=$_POST['prenom'];
   $email=$_POST['email'];
   $mot_pass=$_POST['mot_pass'];
   $adresse=$_POST['adresse'];
   $num_tele=$_POST['num_tele'];
   $date_n =$_POST['date_n'];
   $sexe =$_POST['sexe'];
   $description=$_POST['Description'];
   $spe=$_POST['Specialite'];
   $photo=$_FILES['img']['name'];

   copy($_FILES['img']['tmp_name'], "../image/".$_FILES['img']['name']);
   $requete="update benevol set nom_b='$nom',prenom='$prenom',email='$email',mot_pass='$mot_pass',adresse='$adresse',num_tele='$num_tele',date_n='$date_n',sexe='$sexe',photo='$photo',description='$description',Specialite='$spe' where id_benevol='$id_benevol'";
   mysqli_query($connect,$requete);
  
}else

   $requete="update benevol set nom_b='$nom',prenom='$prenom',email='$email',mot_pass='$mot_pass',adresse='$adresse',num_tele='$num_tele',date_n='$date_n',sexe='$sexe',description='$description',Specialite='$spe'  where id_benevol='$id_benevol'";
   mysqli_query($connect,$requete);
   header('location:profil.php');
}

if(isset($_POST['logout'])) {
  session_destroy();
  header('location:../index.php');
}


?>



<!DOCTYPE html>
<html lang="en">

<head>
  <title>Edit profil</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->  
  <link rel="icon" type="image/png" href=""/>
<!--===============================================================================================-->
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!--===============================================================================================-->
    <link href="../style css/animate.css" rel="stylesheet">
<!--===============================================================================================-->
    <link href="../style css/profil.css" rel="stylesheet">
<!--===============================================================================================-->
</head>

<body>
	
 	
<!-- start nav bar  -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">profile</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <?php   
   $valide=$ligne['validation'];
   if ($valide == 'oui') {
      $val = 'training.php';
   }
 ?>
  <div class=" navbar-collapse" >
    <ul class="navbar-nav ml-auto">
      <span class="border d-none d-lg-block"></span>
      <li class="nav-item dropdown">
        <a class="nav-link d-md-none d-lg-block" href="#" id="a" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <img src="../image/<?php echo ($ligne['photo']);?>" class="d-none d-lg-block rounded-pill ml-5" width="55px" height="55px">
        </a>
        <div class="collapse dropdown-menu text-center" aria-labelledby="a" id="navbarSupportedContent">
          <a class="dropdown-item" href="profil.php">profile</a>
          <a class="dropdown-item" href="Edit Profil.php">Edite </a>
          <a class="dropdown-item" href="<?php echo $val;?>">training</a>
          <a class="dropdown-item" href="message.php">message </a>
          <div class="dropdown-divider"></div>
          <form   method="POST"  enctype="multipart/form-data" action="">
          <a class="dropdown-item" name="logout" href="#"><input class="form-control-plaintext" type="submit" name="logout" value="Log out">
          </a>
          </form>
        </div>
      </li>
      <li class="mt-4 d-none d-lg-block"><span class="ml-3"><?php echo($ligne['nom_b']);?></span></li>
      <li class="mt-4 d-none d-lg-block"><span class="ml-3"><?php echo($ligne['prenom']);?></span></li>
      <span class="border-icon d-none d-lg-block"></span>
      <li class="mt-4 d-none d-lg-block"><a href="" class="ml-4 mr-4"><i class="fas fa-bell"></i></a></li>
      <span class="border d-none d-lg-block"></span>
    </ul>
  	
  </div>
</nav>
<!-- end  nav bar  -->
  <br>
<!--  Start body  -->
<div class="content">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Edit Profile</h4>
                  <p class="card-category">Complete your profile</p>
                </div>
                <div class="card-body">
                  <form   method="POST"  enctype="multipart/form-data" action="">
                    <div class="row">
                      <div class="col-md-5">
                        <div class="form-group">
                          <input type="hidden" name="id_b" value="<?php echo($ligne['id_benevol']);?>">
                          <input type="hidden" name="img" value="<?php echo($ligne['photo']);?>">
                          <label class="bmd-label-floating">First Name</label>
                          <input type="text" class="form-control" name="nom_b" value="<?php echo($ligne['nom_b']);?>">
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Last Name</label>
                          <input type="text" class="form-control" name="prenom" value="<?php echo($ligne['prenom']);?>">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Email address</label>
                          <input type="email" class="form-control" name="email" value="<?php echo($ligne['email']);?>">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Password</label>
                          <input type="text" class="form-control" name="mot_pass" value="<?php echo($ligne['mot_pass']);?>">
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Birth Day</label>
                          <input type="Date" class="form-control" name="date_n" value="<?php echo($ligne['date_n']);?>">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-8">
                        <div class="form-group">
                          <label class="bmd-label-floating">Adress</label>
                          <input type="text" class="form-control" name="adresse" value="<?php echo($ligne['adresse']);?>">
                        </div>
                      </div>
                       <div class="col-md-4">
                        <label class="bmd-label-floating">image</label>
                         <div class="form-group custom-file">
                          <input type="file" class="custom-file-input" name="img" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
                          <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                         </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Number Phone</label>
                          <input type="tel" class="form-control" name="num_tele" value="<?php echo($ligne['num_tele']);?>">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Sexe</label>
                          <select class="form-control" name="sexe">
                            <option value="<?php echo($ligne['sexe']);?>" ><?php echo($ligne['sexe']);?></option>
                            <option value="Homme">Homme</option>
                            <option value="Femme">Femme</option>
                            <option value="autre">autre</option>
                        </select>
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Specialite</label>
                          <select class="form-control" name="Specialite">
                            <option value="<?php echo($ligne['specialite']);?>" ><?php echo($ligne['specialite']);?></option>
                            <option value="Specialist medicine">Specialist Medicine</option>
                            <option value="General Medicine">General Medicine</option>
                            <option value="dentist">Dentist</option>
                            <option value="other">Other</option>
                        </select>                        
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <label>About Me</label>
                          <div class="form-group">
                            <label class="bmd-label-floating"> Lamborghini Mercy, Your chick she so thirsty, I'm in that two seat Lambo.</label>
                            <textarea class="form-control" rows="5" name="Description"><?php echo($ligne['description']);?></textarea>
                          </div>
                        </div>
                      </div>
                    </div>
                   <a href=""><button  type="submit" name="botton" class="btn btn-primary pull-right">Update Profile
                   </button></a>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
            </div>
        
            </div>
          </div>
        </div>
      </div>
<!--  Start body  -->

<!--===============================================================================================-->
  <script src="../jQuery/jquery-3.4.1.min.js"></script>
<!--===============================================================================================-->
  <script src="../jQuery/popper.min.js"></script>
<!--===============================================================================================-->
  <script src="../bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
</body>

<!-- Start footer -->
<hr>
<footer class="footer">
        <div class="container-fluid">
          <nav class="float-left d-inline">
            <ul class="ul-footer ">
              <li >
                <a href="https://www.creative-tim.com">
                  Creative Tim
                </a>
              </li>
              <li>
                <a href="https://creative-tim.com/presentation">
                  About Us
                </a>
              </li>
              <li>
                <a href="http://blog.creative-tim.com">
                  Blog
                </a>
              </li>
              <li>
                <a href="https://www.creative-tim.com/license">
                  Licenses
                </a>
              </li>
            </ul>
          </nav>
          <div class="copyright float-right">
            &copy;
            <script>
              document.write(new Date().getFullYear())
            </script>, made with <i class="material-icons">favorite</i> by
            <a href="https://www.creative-tim.com" target="_blank">Creative Tim</a> for a better web.
          </div>
        </div>
      </footer>

<!-- Start footer -->

</html>