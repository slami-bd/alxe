<?php
session_start();

require_once("connection.php");

$ident_m='';
$ident_e='';
$ident_f='';
$ident_a='';
$ident_etudier='';
if (isset($_GET['ident_m'])) {
  $ident_m='true';
}if (isset($_GET['ident_e'])) {
  $ident_e='true';
}if (isset($_GET['ident_f'])) {
  $ident_f='true';
}if (isset($_GET['ident_a'])) {
  $ident_a='true';
}if (isset($_GET['ident_etudier'])) {
  $ident_etudier='true';
}
// _______________________________________benevol______________________________________//

if(isset($_POST['botton_b'])) {
   $nom=$_POST['nom'];
   $prenom=$_POST['prenom'];
   $email=$_POST['email'];
   $mot_pass=$_POST['mot_pass'];
   $adresse=$_POST['adresse'];
   $num_tele=$_POST['num_tele'];
   $date =$_POST['date'];
   $sexe =$_POST['sexe'];
   $specialite =$_POST['specialite'];
   $description =$_POST['description'];

    if ($_FILES['photo']['error']==0){
   $nom=$_POST['nom'];
   $prenom=$_POST['prenom'];
   $email=$_POST['email'];
   $mot_pass=$_POST['mot_pass'];
   $adresse=$_POST['adresse'];
   $num_tele=$_POST['num_tele'];
   $date =$_POST['date'];
   $sexe =$_POST['sexe'];
   $specialite =$_POST['specialite'];
   $description =$_POST['description'];
   $photo=$_FILES['photo']['name'];

   copy($_FILES['photo']['tmp_name'], "image/".$_FILES['photo']['name']);

   $requet="insert into benevol(nom_b,prenom,email,mot_pass,adresse,num_tele,date_n,sexe,photo,specialite,description) values ('$nom','$prenom','$email','$mot_pass','$adresse','$num_tele','$date','$sexe','$photo','$specialite','$description')";
 }else

   $requet="insert into benevol(nom_b,prenom,email,mot_pass,adresse,num_tele,date_n,sexe,specialite,description) values ('$nom','$prenom','$email','$mot_pass','$adresse','$num_tele','$date','$sexe','$specialite','$description')";
  mysqli_query($connect,$requet);
  header('location:list table.php');
}

// _______________________________________ensignan______________________________________//

if (isset($_POST['botton_e'])) {
   $nom=$_POST['nom'];
   $prenom=$_POST['prenom'];
   $num_tele=$_POST['num_tele'];
   $spicialite=$_POST['spicialite'];

 if ($_FILES['img']['error']==0){
   $nom=$_POST['nom'];
   $prenom=$_POST['prenom'];
   $num_tele=$_POST['num_tele'];
   $spicialite=$_POST['spicialite'];
   $photo=$_FILES['img']['name'];

   copy($_FILES['img']['tmp_name'], "image/".$_FILES['img']['name']);

    $requet="insert into ensginants(nom,prenom,num_tele,spicialite,photo) values ('$nom','$prenom','$num_tele','$spicialite','$photo')";
}else
   $requet="insert into ensginants(nom,prenom,num_tele,spicialite) values ('$nom','$prenom','$num_tele','$spicialite')";
   mysqli_query($connect,$requet);
   header('location:list table.php');
}

// ________________________________________formation______________________________________________//


if (isset($_POST['botton_f'])) {
   $nom=$_POST['nom'];
   $date_debut=$_POST['date_debut'];
   $date_fin=$_POST['date_fin'];
   $desscription=$_POST['desscription'];

   $requete="insert into formations(nom_f,desscription,date_debut,date_fin) values ('$nom','$desscription','$date_debut','$date_fin')";
   mysqli_query($connect,$requete);
   header('location:list table.php');
}

// _________________________________________admin_____________________________________________//


if (isset($_POST['botton_a'])) {
   $nom=$_POST['nom'];
   $niveau=$_POST['niveau'];
   $mot_pass=$_POST['mot_pass'];

if ($_FILES['img']['error']==0){
   $nom=$_POST['nom'];
   $niveau=$_POST['niveau'];
   $mot_pass=$_POST['mot_pass'];
   $photo=$_FILES['img']['name'];

   copy($_FILES['img']['tmp_name'], "image/".$_FILES['img']['name']);

   $requete="insert into adminstrateur (nom,niveau,mot_pass,photo) values ('$nom','$niveau','$mot_pass','$photo')";
}else

   $requete="insert into adminstrateur (nom,niveau,mot_pass) values ('$nom','$niveau','$mot_pass')";
   mysqli_query($connect,$requete);
   header('location:list table.php');
}

// _______________________________________End_______________________________________________//


if(isset($_POST['botton_etudier'])) {
 $id_formation=$_POST['id_formation'];
 $id_ensginan=$_POST['id_ensginan'];
 $date_etude=$_POST['date_etude'];
 $requet="insert into etudier (id_formation,id_ensginan,date_etude) values ('$id_formation','$id_ensginan','$date_etude')";
  mysqli_query($connect,$requet);
  header('location:list table.php');
  }
// _______________________________________End_______________________________________________//


if(isset($_POST['logout'])) {
  session_destroy();
  header('location:../index.php');
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>add benevol</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->  
  <link rel="icon" type="image/png" href=""/>
<!--===============================================================================================-->
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!--===============================================================================================-->
   <link href="../font awesome/css/all.css" rel="stylesheet">
<!--===============================================================================================-->
    <link href="../style css/animate.css" rel="stylesheet">
<!--===============================================================================================-->
    <link href="../style css/aside-bar.css" rel="stylesheet">
<!--===============================================================================================-->
    <link href="../style css/dashboard.css" rel="stylesheet">
<!--===============================================================================================-->

</head>
<body>

<!-- ________________________________________________________html_____________________________________________________-->

<div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <div class="sidebar-header">
                <h3>EL BADR BLIDA</h3>
            </div>

            <ul class="list-unstyled components">
                <p>menu</p>
                <li class="active">
                    <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">add profil
                    </a>
                    <ul class="collapse list-unstyled" id="homeSubmenu">
                         <li>
                            <a href="add volunteer.php?ident_m=<?php echo 'true'; ?>">add volunteer</a>
                        </li>
                        <li>
                            <a href="add volunteer.php?ident_e=<?php echo 'true'; ?>">add ensignan </a>
                        </li>
                        <li>
                            <a href="add volunteer.php?ident_f=<?php echo 'true'; ?>">add formation </a>
                        </li>
                        <li>
                            <a href="add volunteer.php?ident_a=<?php echo 'true'; ?>">add admin</a>
                        </li>
                        <li>
                          <a href="add volunteer.php?ident_etudier=<?php echo 'true'; ?>">formation etudier</a>
                        </li>
                    </ul>    
                </li>
               <li>
                    <a href="validation.php">validation</a>
                </li>
            
                <li>
                    <a href="statistic.php">statistics</a>
                </li>
                <li>
                    <a href="message_admin.php">Contact</a>
                </li>
            </ul>

            <ul class="list-unstyled CTAs">
                <li>
                    <a href="" class="download">Download source</a>
                </li>
                <li>
                    <a href="" class="article">Back to article</a>
                </li>
            </ul>
        </nav>
<!-- ________________________________________________________html_____________________________________________________-->

        <!-- Page Content  -->
        <div id="content">

            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">

                    <button type="button" id="sidebarCollapse" class="btn btn-info">
                        <i class="fas fa-align-left"></i>
                        <span>add benevol</span>
                    </button>
                    <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fas fa-align-justify"></i>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                       
                           <ul class="nav navbar-nav ml-auto d-lg-none">
                            <li class="nav-item active">
                                <a class="nav-link text-center" href="list table.php">Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-center" href="#">Notifiction</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-center" href="profile admin.php">Profil</a>
                            </li>
                            <li class="nav-item">
                          <form   method="POST"  enctype="multipart/form-data" action="">
                                <a class="dropdown-item" name="logout" href="#"><input class="form-control-plaintext" type="submit" name="logout" value="Log out">
                          </a>
                          </form>
                            </li>
                        </ul>



                      <div class="ml-auto display-nav">
                      <ul class="navbar-nav    ">
                      <li class="nav-item">
                        <a class="nav-link" href="list table.php">
                          <i class="fab fa-buromobelexperte"></i>
                        </a>
                      </li>
                      <li class="nav-item dropdown">
                        <a class="nav-link" href="" id="a" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <i class="fas fa-bell"></i>
                          <span class="notification">5</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="a">
                          <a class="dropdown-item" href="#">Mike John responded to your email</a>
                          <a class="dropdown-item" href="#">You have 5 new tasks</a>
                          <a class="dropdown-item" href="#">You're now friend with Andrew</a>
                          <a class="dropdown-item" href="#">Another Notification</a>
                          <a class="dropdown-item" href="#">Another One</a>
                        </div>
                      </li>
                      <li class="nav-item dropdown">
                        <a class="nav-link" href="" id="navbarDropdownProfile" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                         <i class="fas fa-user"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownProfile">
                          <a class="dropdown-item" href="Profile admin.php">Profile</a>
                          <a class="dropdown-item" href="#">Settings</a>
                          <div class="dropdown-divider"></div>
                          <form   method="POST"  enctype="multipart/form-data" action="">
                          <a class="dropdown-item" name="logout" href="#"><input class="form-control-plaintext" type="submit" name="logout" value="Log out">
                          </a>
                          </form>
                        </div>
                      </li>
                    </ul>
                  </div>

               </div>
            </div>
        </nav>
<!-- ________________________________________________________benevol_____________________________________________________-->






<div class="content">
        <div class="container">
          <?php if ($ident_m =='true') {  ?>
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Add Profile Benevol</h4>
                  <p class="card-category">Complete your profile</p>
                </div>
                <div class="card-body">
                  <form   method="POST"  enctype="multipart/form-data" action="">
                    <div class="row">
                      <div class="col-md-5">
                        <div class="form-group">
                          <label class="bmd-label-floating">First Name</label>
                          <input type="text" class="form-control" name="nom" placeholder="">
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Last Name</label>
                          <input type="text" class="form-control" name="prenom" placeholder="">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Email address</label>
                          <input type="email" class="form-control" name="email" placeholder="email@gmail.com">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Password</label>
                          <input type="text" class="form-control" name="mot_pass" placeholder="">
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Birth Day</label>
                          <input type="Date" class="form-control" name="date" placeholder="">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-8">
                        <div class="form-group">
                          <label class="bmd-label-floating">Adress</label>
                          <input type="text" class="form-control" name="adresse" placeholder="">
                        </div>
                      </div>
                       <div class="col-md-4">
                        <label class="bmd-label-floating">image</label>
                         <div class="form-group custom-file">
                          <input type="file" class="custom-file-input" name="photo" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
                          <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                         </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Number Phone</label>
                          <input type="tel" class="form-control" name="num_tele" placeholder="">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Sexe</label>
                          <select class="form-control" name="sexe">
                            <option placeholder="Homme">Homme</option>
                            <option placeholder="Femme">Femme</option>
                            <option placeholder="autre">autre</option>
                        </select>
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Specialite</label>
                          <select class="form-control" name="specialite">
                            <option placeholder="other">Other</option>
                            <option placeholder="Specialist medicine">Specialist Medicine</option>
                            <option placeholder="General Medicine">General Medicine</option>
                            <option placeholder="dentist">Dentist</option>
                        </select>                        
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <label>About Me</label>
                          <div class="form-group">
                            <label class="bmd-label-floating"> Lamborghini Mercy, Your chick she so thirsty, I'm in that two seat Lambo.</label>
                            <textarea class="form-control" rows="5" name="description"></textarea>
                          </div>
                        </div>
                      </div>
                    </div>
                   <a href=""><button  type="submit" name="botton_b" class="btn btn-primary pull-right">Add Benevol
                   </button></a>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
             </div>
            </div>
          <?php } ?>
<!-- _______________________________________end benevol ______________________________________-->
            <br>
            <br>
<!-- _______________________________________ensignan______________________________________-->
          <?php if ($ident_e =='true') {  ?>
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Add Profile Ensnigana</h4>
                  <p class="card-category">Complete your profile</p>
                </div>
                <div class="card-body">
                  <form   method="POST"  enctype="multipart/form-data" action="">
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">First Name</label>
                          <input type="text" class="form-control" name="nom" placeholder="">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Last Name</label>
                          <input type="text" class="form-control" name="prenom" placeholder="">
                        </div>
                      </div>
                      
                       <div class="col-md-4">
                        <label class="bmd-label-floating">image</label>
                         <div class="form-group custom-file">
                          <input type="file" class="custom-file-input" name="img" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
                          <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                         </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Number Phone</label>
                          <input type="tel" class="form-control" name="num_tele" placeholder="">
                        </div>
                      </div>
                       <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Spicialite</label>
                          <input type="text" class="form-control" name="spicialite" placeholder="">
                        </div>
                      </div>
                    </div>
                   <a href=""><button  type="submit" name="botton_e" class="btn btn-primary pull-right">Add Ensignan
                   </button></a>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
             </div>
            </div>
          <?php } ?>
<!-- _______________________________________end______________________________________-->
            <br>
            <br>
<!-- _______________________________________formation______________________________________-->
      <?php if ($ident_f =='true') {  ?>
      <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Add Profile Formation</h4>
                  <p class="card-category">Complete your profile</p>
                </div>
                <div class="card-body">
                  <form   method="POST"  enctype="multipart/form-data" action="">
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Name</label>
                          <input type="text" class="form-control" name="nom" placeholder="">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">date_debut</label>
                          <input type="date" class="form-control" name="date_debut" placeholder="">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">date_fin</label>
                          <input type="date" class="form-control" name="date_fin" placeholder="">
                        </div>
                      </div>
                       <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">desscription</label>
                          <input type="text" class="form-control" name="desscription" placeholder="">
                        </div>
                      </div>
                 
                    </div>
                   <a href=""><button  type="submit" name="botton_f" class="btn btn-primary pull-right">Add Formation
                   </button></a>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
             </div>
            </div>
          <?php } ?>
<!-- _______________________________________End______________________________________-->



<!-- _______________________________________Admin______________________________________-->
    <?php if ($ident_a =='true') {  ?>
      <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Add Profile Admin</h4>
                  <p class="card-category">Complete your profile</p>
                </div>
                <div class="card-body">
                  <form   method="POST"  enctype="multipart/form-data" action="">
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">First Name</label>
                          <input type="text" class="form-control" name="nom" placeholder="">
                        </div>
                      </div>
                       <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">niveau</label>
                          <select class="form-control" name="niveau">
                            <option placeholder="admin">admin</option>
                            <option placeholder="editeur">editeur</option>
                            <option placeholder="moderateur">moderateur</option>
                            <option placeholder="analyst">analyst</option>
                          </select>
                        </div>
                      </div>
                       <div class="col-md-4">
                        <label class="bmd-label-floating">image</label>
                         <div class="form-group custom-file">
                          <input type="file" class="custom-file-input" name="img" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
                          <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                         </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Password</label>
                          <input type="text" class="form-control" name="mot_pass" placeholder="">
                        </div>
                      </div>
    
                    </div>
                   <a href=""><button  type="submit" name="botton_a" class="btn btn-primary pull-right">Add Admin
                   </button></a>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
             </div>
            </div>
        <?php } ?>
<!-- _______________________________________End______________________________________-->

<!-- _______________________________________formation etduier______________________________________-->
    <?php if ($ident_etudier =='true') {  ?>
      <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Add formation etudier</h4>
                  <p class="card-category">Complete your profile</p>
                </div>
                <div class="card-body">
                  <form   method="POST"  enctype="multipart/form-data" action="">
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">date_etude</label>
                          <input type="date" class="form-control" name="date_etude" placeholder="">
                        </div>
                      </div>
                       <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">id - formation</label>
                          <select class="form-control" name="id_formation">
                            <?php  
                            $req = "select * from formations ";
                            $res = mysqli_query($connect,$req);
                            while ($ligne_aa= mysqli_fetch_array($res)){;
                            ?>
                            <option placeholder="<?php echo($ligne_aa['id_formation']);?>">
                              <?php echo($ligne_aa['id_formation']); echo ' - '.($ligne_aa['nom_f']);?>
                            </option>
                            <?php } ?>
                          </select>
                        </div>
                      </div>
                        <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">id - ensginan</label>
                          <select class="form-control" name="id_ensginan">
                            <?php  
                            $req = "select * from ensginants ";
                            $res = mysqli_query($connect,$req);
                            while ($ligne_z= mysqli_fetch_array($res)){;
                            ?>
                            <option placeholder="<?php echo($ligne_z['id_ensginan']);?>">
                              <?php echo($ligne_z['id_ensginan']);echo ' - '.($ligne_z['nom']);?>
                            </option>
                            <?php } ?>
                          </select>
                        </div>
                      </div>
                    </div>
                   <a href=""><button  type="submit" name="botton_etudier" class="btn btn-primary pull-right">Add etudier
                   </button></a>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
             </div>
            </div>
        <?php } ?>
<!-- _______________________________________end formation etduier______________________________________-->



          </div>
        </div>







<!-- ________________________________________________________wrapper_____________________________________________________-->
        </div>
    </div>
<!-- ________________________________________________________html_____________________________________________________-->

	


<!--===============================================================================================-->
  <script src="../jQuery/sildebare js/jQuery v3.3.1.js"></script>
<!--===============================================================================================-->
 <script src="../jQuery/sildebare js/jquery mCustomScrollbar .min.js"></script>
<!--===============================================================================================-->
  <script src="../jQuery/popper.min.js"></script>
<!--===============================================================================================-->
  <script src="../bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
    <script>
        $(document).ready(function () {
            $("#sidebar").mCustomScrollbar({
                theme: "minimal"
            });

            $('#sidebarCollapse').on('click', function () {
                $('#sidebar, #content').toggleClass('active');
                $('.collapse.in').toggleClass('in');
                $('a[aria-expanded=true]').attr('aria-expanded', 'false');
            });
        });

    </script>
</body>
</html>