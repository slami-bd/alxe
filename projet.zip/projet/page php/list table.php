<?php 
session_start();


require_once("connection.php");
$id_admin= $_SESSION['id_admin'];



// start parte delete benevol
if(isset($_GET['photo'])){
$image=$_GET['photo'];  
$req="select count(*) as x from benevol where photo='$image'";
$res= mysqli_query($connect,$req);
while ($ligne=mysqli_fetch_array($res)){
if(($ligne['x']==1) and ($image<>'admin.png'))
unlink("../image/".$image);
}
$mat=$_GET['ident'];
$del1="delete from benevol where id_benevol ='$mat'";
mysqli_query($connect,$del1); 
$del2="delete from inscription where id_benevol ='$mat'";
mysqli_query($connect,$del2); 
} 
// end parte delete benevol


// start parte delete formation
if(isset($_GET['ident_f'])){
$mat=$_GET['ident_f'];
$del1="delete from formations where id_formation ='$mat'";
mysqli_query($connect,$del1);
$del2="delete from inscription where id_formation_in ='$mat'";
mysqli_query($connect,$del2); 
$del3="delete from etudier where id_formation ='$mat'"; 
mysqli_query($connect,$del3);    
} 
// end parte mdelete formation


// start parte delete admin
if(isset($_GET['photo_a'])){
$image=$_GET['photo_a'];  
$req="select count(*) as x from adminstrateur where photo='$image'";
$res= mysqli_query($connect,$req);
while ($ligne=mysqli_fetch_array($res)){
if(($ligne['x']==1) and ($image<>'admin.png'))
unlink("image/".$image);
}
$mat=$_GET['ident_a'];
$del1="delete from adminstrateur where id_admin='$mat'";
mysqli_query($connect,$del1); 
} 
// end parte mdelete adminn


// start parte delete prof
if(isset($_GET['photo_e'])){
$image=$_GET['photo_e'];  
$req="select count(*) as x from ensginants where photo='$image'";
$res= mysqli_query($connect,$req);
while ($ligne=mysqli_fetch_array($res)){
if(($ligne['x']==1) and ($image<>'admin.png'))
unlink("../image/".$image);
}
$mat=$_GET['ident_e'];
$del1="delete from ensginants where id_ensginan='$mat'";
mysqli_query($connect,$del1);
$del2="delete from    etudier where id_ensginan='$mat'";
mysqli_query($connect,$del2); 
} 
// end parte mdelete prof


// start parte delete table etudier
if(isset($_GET['ident_et'])){
$mat=$_GET['ident_et'];
$del1="delete from etudier where id_formation ='$mat'";
mysqli_query($connect,$del1);   
} 
// end parte mdelete table etudier


// start parte delete inscription
if(isset($_GET['ident_in'])){
$mat=$_GET['ident_in'];
$maq=$_GET['ident_id'];
$del1="delete from inscription where id_formation_in ='$mat' and id_benevol='$maq'";
mysqli_query($connect,$del1);   
} 
// end parte mdelete inscription

// start create file of extation .exl

// start create file of extation .exl

if(isset($_POST['logout'])) {
  session_destroy();
  header('location:../index.php');
}
?>
<!-- ________________________________________________________html_____________________________________________________-->



<!DOCTYPE html>
<html lang="en">

<head>
  <title>list table</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->  
  <link rel="icon" type="image/png" href=""/>
<!--===============================================================================================-->
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!--===============================================================================================-->
   <link href="../font awesome/css/all.css" rel="stylesheet">
<!--===============================================================================================-->
    <link href="../style css/animate.css" rel="stylesheet">
<!--===============================================================================================-->
    <link href="../style css/aside-bar.css" rel="stylesheet">
<!--===============================================================================================-->
    <link href="../style css/dashboard.css" rel="stylesheet">
<!--===============================================================================================-->

</head>
<body>

<!-- ________________________________________________________html_____________________________________________________-->

<div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <div class="sidebar-header">
                <h3>EL BADR BLIDA</h3>
            </div>

            <ul class="list-unstyled components">
                <p>menu</p>
                <li class="active">
                    <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">add profil
                    </a>
                    <ul class="collapse list-unstyled" id="homeSubmenu">
                         <li>
                            <a href="add volunteer.php?ident_m=<?php echo 'true'; ?>">add volunteer</a>
                        </li>
                        <li>
                            <a href="add volunteer.php?ident_e=<?php echo 'true'; ?>">add ensignan </a>
                        </li>
                        <li>
                            <a href="add volunteer.php?ident_f=<?php echo 'true'; ?>">add formation </a>
                        </li>
                        <li>
                            <a href="add volunteer.php?ident_a=<?php echo 'true'; ?>">add admin</a>
                        </li>
                        <li>
                          <a href="add volunteer.php?ident_etudier=<?php echo 'true'; ?>">formation etudier</a>
                        </li>
                    </ul>    
                </li>
                <li>
                    <a href="validation.php">validation</a>
                </li>
            
                <li>
                    <a href="statistic.php">statistics</a>
                </li>
                <li>
                    <a href="message_admin.php">Contact</a>
                </li>
            </ul>

            <ul class="list-unstyled CTAs">
                <li>
                    <a href="" class="download">Download source</a>
                </li>
                <li>
                    <a href="" class="article">Back to article</a>
                </li>
            </ul>
        </nav>
<!-- ________________________________________________________html_____________________________________________________-->

        <!-- Page Content  -->
        <div id="content">

            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">

                    <button type="button" id="sidebarCollapse" class="btn btn-info">
                        <i class="fas fa-align-left"></i>
                        <span>show data base</span>
                    </button>
                    <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fas fa-align-justify"></i>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                       
                          <ul class="nav navbar-nav ml-auto d-lg-none">
                            <li class="nav-item active">
                                <a class="nav-link text-center" href="list table.php">Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-center" href="#">Notifiction</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-center" href="profile admin.php">Profile</a>
                            </li>
                            <li class="nav-item">
                          <form   method="POST"  enctype="multipart/form-data" action="">
                                <a class="dropdown-item" name="logout" href="#"><input class="form-control-plaintext" type="submit" name="logout" value="Log out">
                          </a>
                          </form>
                            </li>
                        </ul>


                      <div class="ml-auto display-nav">
                      <ul class="navbar-nav    ">
                      <li class="nav-item">
                        <a class="nav-link" href="list table.php">
                          <i class="fab fa-buromobelexperte"></i>
                        </a>
                      </li>
                      <li class="nav-item dropdown">
                        <a class="nav-link" href="" id="a" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <i class="fas fa-bell"></i>
                          <span class="notification">5</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="a">
                          <a class="dropdown-item" href="#">Mike John responded to your email</a>
                          <a class="dropdown-item" href="#">You have 5 new tasks</a>
                          <a class="dropdown-item" href="#">You're now friend with Andrew</a>
                          <a class="dropdown-item" href="#">Another Notification</a>
                          <a class="dropdown-item" href="#">Another One</a>
                        </div>
                      </li>
                      <li class="nav-item dropdown">
                        <a class="nav-link" href="" id="navbarDropdownProfile" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                         <i class="fas fa-user"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownProfile">
                          <a class="dropdown-item" href="profile admin.php">Profile</a>
                          <a class="dropdown-item" href="#">Settings</a>
                          <div class="dropdown-divider"></div>
                          <form   method="POST"  enctype="multipart/form-data" action="">
                          <a class="dropdown-item" name="logout" href="#"><input class="form-control-plaintext" type="submit" name="logout" value="Log out">
                          </a>
                          </form>
                        </div>
                      </li>
                    </ul>
                  </div>

                     


                    </div>
                </div>
            </nav>
<!-- ________________________________________________________html_____________________________________________________-->

    <div class="content">
              <div class="container-fluid">
                <div class="row">
                  <div class="col-md-12">
                    <div class="card">
                      <div class="card-header card-header-primary">
                        <h4 class="card-title "> Table benevol</h4>  <?php //echo $id_admin; ?>
                        <p class="card-category"> Here is a subtitle for this table</p>
                      </div>
                      <div class="card-body">
                        <div class="table-responsive">
                          <table class="table">
                            <thead class=" text-primary">
                            <th>photo</th><th>id</th> <th>nom</th> <th>prenom</th> 
                            <th>email</th> <th>date_naissance </th> <th>mot_pass</th> 
                            <th>adresse</th> <th>Telephone</th> <th>sexe</th> <th>valide</th>
                            <th>specialite</th><th>description</th>
                            </thead>
                            <?php $ex= mysqli_query ($connect,'select * from benevol '); ?>
                            <?php while ($ligne = mysqli_fetch_array($ex)) { ?>
                            <tbody>
                              <tr>
                                <td>
                                <img src="../image/<?php echo ($ligne['photo']);  ?>" width="60px" height="60px" /></td>
                                <td><?php echo($ligne['id_benevol']);?></td> 
                                <td><?php echo($ligne['nom_b']);?></td> 
                                <td><?php echo($ligne['prenom']);?></td> 
                                <td><?php echo($ligne['email']);?></td> 
                                <td><?php echo($ligne['date_n']);?></td>
                                <td><?php echo($ligne['mot_pass']);?></td>
                                <td><?php echo($ligne['adresse']);?></td> 
                                <td><?php echo($ligne['num_tele']);?></td> 
                                <td><?php echo($ligne['sexe']);?></td>
                                <td><?php echo($ligne['validation']);?></td>
                                <td><?php echo($ligne['specialite']);?></td>
                                <div ><td class="a text-primary"><?php echo($ligne['description']);?></td></div>
                                <td>
                                <a href="list table.php?ident=<?php echo $ligne['id_benevol']; ?>&photo=<?php echo $ligne['photo']; ?>"><i class="far fa-trash-alt fa-lg"></i></a>
                                </td>
                                <td><span><a href="update.php?ident_m=<?php echo $ligne['id_benevol']; ?>"><i class="far fa-edit fa-lg"></i></a></span>
                                </td>
                              </tr>
                              <?php } ?>
                            </tbody>
                          </table>
                        </div>

                      </div>

                    </div>
                    <div class="">
                    </div>
                  </div>
                </div>
                <br>
                <!--  spaice btwen tables  -->
                <br>
                <div class="row">
                  <div class="col-md-12">
                    <div class="card">
                      <div class="card-header card-header-primary">
                        <h4 class="card-title "> Table formations</h4>
                        <p class="card-category"> Here is a subtitle for this table</p>
                      </div>
                      <div class="card-body">
                        <div class="table-responsive">
                          <table class="table">
                            <thead class=" text-primary">
                            <th>id</th><th>nom</th> <th>date bebut</th> <th>date fin</th> <th>desscription</th>
                            </thead>
                            <?php $ex= mysqli_query ($connect,'select * from formations '); ?>
                            <?php while ($ligne = mysqli_fetch_array($ex)) { ?>
                            <tbody>
                              <tr>
                                <td><?php echo($ligne['id_formation']);?></td> 
                                <td><?php echo($ligne['nom_f']);?></td> 
                                <td><?php echo($ligne['date_debut']);?></td> 
                                <td><?php echo($ligne['date_fin']);?></td> 
                                <td><?php echo($ligne['desscription']);?></td>
                                <td>
                                  <a href="list table.php?ident_f=<?php echo $ligne['id_formation']; ?>"><i class="far fa-trash-alt fa-lg"></i></a>
                                </td> 
                                <td><span><a href="update.php?ident_f=<?php echo $ligne['id_formation']; ?>"><i class="far fa-edit fa-lg"></i></a></span>
                                </td>
                              </tr>
                              <?php } ?>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <br>
                <!--  spaice btwen tables  -->
                <br>
                 <div class="row">
                  <div class="col-md-12">
                    <div class="card">
                      <div class="card-header card-header-primary">
                        <h4 class="card-title ">Table admin</h4>
                        <p class="card-category"> Here is a subtitle for this table</p>
                      </div>
                      <div class="card-body">
                        <div class="table-responsive">
                          <table class="table">
                            <thead class=" text-primary">
                            <th>photo</th><th>id</th><th>nom</th> <th>grade</th> <th>password</th> 
                            </thead>
                            <?php $ex= mysqli_query ($connect,'select * from adminstrateur '); ?>
                            <?php while ($ligne = mysqli_fetch_array($ex)) { ?>
                            <tbody>
                              <tr>
                                <td>
                                <img src="../image/<?php echo ($ligne['photo']);  ?>" width="60px" height="60px" /></td>
                                <td><?php echo($ligne['id_admin']);?></td> 
                                <td><?php echo($ligne['nom']);?></td> 
                                <td><?php echo($ligne['niveau']);?></td> 
                                <td><?php echo($ligne['mot_pass']);?></td>
                                <td>
                                  <a href="list table.php?ident_a=<?php echo $ligne['id_admin']; ?>&photo_a=<?php echo $ligne['photo']; ?>"><i class="far fa-trash-alt fa-lg"></i></a>
                                </td> 
                                <td><span><a href="update.php?ident_a=<?php echo $ligne['id_admin']; ?>"><i class="far fa-edit fa-lg"></i></a></span>
                                </td>
                              </tr>
                              <?php } ?>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <br>
                <!--  spaice btwen tables  -->
                <br>
                  <div class="row">
                  <div class="col-md-12">
                    <div class="card">
                      <div class="card-header card-header-primary">
                        <h4 class="card-title ">Table inscription</h4>
                        <p class="card-category"> Here is a subtitle for this table</p>
                      </div>
                      <div class="card-body">
                        <div class="table-responsive">
                          <table class="table">
                            <thead class=" text-primary">
                            <th>id_benevol</th><th>nom benevol</th><th>id_formation</th> <th>nom formation</th> <th>date</th><th>validire</th> 
                            </thead>
                            <?php $ex= mysqli_query ($connect,'
                              select *  from benevol
                                join inscription
                                  on benevol.id_benevol=inscription.id_benevol
                                join formations
                                  on inscription.id_formation_in=formations.id_formation '); ?>
                            <?php while ($ligne = mysqli_fetch_array($ex)) { ?>
                            <tbody>
                              <tr>
                                <td><?php echo($ligne['id_benevol']);?></td> 
                                <td><?php echo($ligne['nom_b']);?></td>
                                <td><?php echo($ligne['id_formation_in']);?></td>
                                <td><?php echo($ligne['nom_f']);?></td>
                                <td><?php echo($ligne['date_insc']);?></td>
                                <td><?php echo($ligne['valider']);?></td>
                                <td>
                                  <a href="list table.php?ident_in=<?php echo $ligne['id_formation']; ?>&ident_id=<?php echo $ligne['id_benevol']; ?>"><i class="far fa-trash-alt fa-lg"></i></a>
                                </td> 
                              </tr>
                              <?php } ?>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <br>
                <!--  spaice btwen tables  -->
                <br>
                <div class="row">
                  <div class="col-md-12">
                    <div class="card">
                      <div class="card-header card-header-primary">
                        <h4 class="card-title ">Table etudier</h4>
                        <p class="card-category"> Here is a subtitle for this table</p>
                      </div>
                      <div class="card-body">
                        <div class="table-responsive">
                          <table class="table">
                            <thead class=" text-primary">
                            <th>id formation</th><th>nom fomrmation</th><th>id ensginan</th><th>nom ensignan</th><th>date etude</th><th></th>
                            </thead>
                            <?php $ex= mysqli_query ($connect,'
                              select *  from ensginants
                               join etudier
                                  on ensginants.id_ensginan=etudier.id_ensginan
                               join formations
                                  on etudier.id_formation=formations.id_formation
                             '); ?>
                            <?php while ($ligne = mysqli_fetch_array($ex)) { ?>
                            <tbody>
                              <tr>
                                <td><?php echo($ligne['id_formation']);?></td>
                                <td><?php echo($ligne['nom_f']);?></td> 
                                <td><?php echo($ligne['id_ensginan']);?></td>
                                <td><?php echo($ligne['nom']);?></td> 
                                <td><?php echo($ligne['date_etude']);?></td>
                                <td>
                                  <a href="list table.php?ident_et=<?php echo $ligne['id_formation'] ; ?>"><i class="far fa-trash-alt fa-lg"></i></a>
                                </td> 
                              </tr>
                              <?php } ?>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <br>
                <!--  spaice btwen tables  -->
                <br>
                <div class="row">
                  <div class="col-md-12">
                    <div class="card">
                      <div class="card-header card-header-primary">
                        <h4 class="card-title "> Table ensginan</h4>
                        <p class="card-category"> Here is a subtitle for this table</p>
                      </div>
                      <div class="card-body">
                        <div class="table-responsive">
                          <table class="table">
                            <thead class=" text-primary">
                            <th>photo</th><th>id</th> <th>nom</th> <th>prenom</th> 
                            <th>num_tele</th> <th>spicialite </th> 
                            </thead>
                            <?php $ex= mysqli_query ($connect,'select * from ensginants '); ?>
                            <?php while ($ligne = mysqli_fetch_array($ex)) { ?>
                            <tbody>
                              <tr>
                                <td>
                                <img src="../image/<?php echo ($ligne['photo']);  ?>" width="60px" height="60px" />
                                </td>
                                <td><?php echo($ligne['id_ensginan']);?></td> 
                                <td><?php echo($ligne['nom']);?></td> 
                                <td><?php echo($ligne['prenom']);?></td> 
                                <td><?php echo($ligne['num_tele']);?></td> 
                                <td><?php echo($ligne['spicialite']);?></td>
                                <td>
                                  <a href="list table.php?ident_e=<?php echo $ligne['id_ensginan']; ?>&photo_e=<?php echo $ligne['photo']; ?>"><i class="far fa-trash-alt fa-lg"></i></a>
                                </td>
                                <td><span><a href="update.php?ident_e=<?php echo $ligne['id_ensginan']; ?>"><i class="far fa-edit fa-lg"></i></a></span>
                                </td>
                              </tr>
                              <?php } ?>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>






<!-- ___________________________________________________contant body_____________________________________________________-->
              </div>
            </div>
<!-- ________________________________________________________wrapper_____________________________________________________-->
        </div>
    </div>
<!-- ________________________________________________________html_____________________________________________________-->

	


<!--===============================================================================================-->
  <script src="../jQuery/sildebare js/jQuery v3.3.1.js"></script>
<!--===============================================================================================-->
 <script src="../jQuery/sildebare js/jquery mCustomScrollbar .min.js"></script>
<!--===============================================================================================-->
  <script src="../jQuery/popper.min.js"></script>
<!--===============================================================================================-->
  <script src="../bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
    <script>
        $(document).ready(function () {
            $("#sidebar").mCustomScrollbar({
                theme: "minimal"
            });

            $('#sidebarCollapse').on('click', function () {
                $('#sidebar, #content').toggleClass('active');
                $('.collapse.in').toggleClass('in');
                $('a[aria-expanded=true]').attr('aria-expanded', 'false');
            });
        });

    </script>
</body>
</html>