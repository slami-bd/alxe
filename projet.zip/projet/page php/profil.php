  <?php
session_start();

require_once("connection.php");

  if (isset($_SESSION['ident'])) {
    $requete="select  * from benevol order by id_benevol desc ";
    $req=mysqli_query($connect,$requete);
    $ligne_b=mysqli_fetch_array($req); 
    $id_bn=$ligne_b['id_benevol'];
    $_SESSION['id_benevol']=$id_bn;
  }
  
   if ($_SESSION['ident_q']='true') {
   $id_bn=$_SESSION['id_benevol'];
   }

  $ex= mysqli_query ($connect,"select * from benevol where id_benevol='$id_bn'");

if(isset($_POST['logout'])) {
  session_destroy();
  header('location:../index.php');
}



while ($ligne = mysqli_fetch_array($ex)){ 

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <title>profil</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->  
  <link rel="icon" type="image/png" href=""/>
<!--===============================================================================================-->
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!--===============================================================================================-->
    <link href="../style css/animate.css" rel="stylesheet">
<!--===============================================================================================-->
    <link href="../style css/profil.css" rel="stylesheet">
<!--===============================================================================================-->
</head>
<body>
	


<!-- start nav bar  -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">profile</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
 <?php   
   $valide=$ligne['validation'];
   if ($valide == 'oui') {
      $val = 'training.php';
   }
 ?>
  <div class=" navbar-collapse" >
    <ul class="navbar-nav ml-auto">
      <span class="border d-none d-lg-block"></span>
      <li class="nav-item dropdown">
        <a class="nav-link d-md-none d-lg-block" href="#" id="a" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <img src="../image/<?php echo ($ligne['photo']);?>" class="d-none d-lg-block rounded-pill ml-5" width="55px" height="55px">
        </a>
        <div class="collapse dropdown-menu text-center" aria-labelledby="a" id="navbarSupportedContent">
          <a class="dropdown-item" href="profil.php">profile</a>
          <a class="dropdown-item" href="Edit Profil.php">Edite </a>
          <a class="dropdown-item" href="<?php echo $val;?>">training</a>
          <a class="dropdown-item" href="message.php">message </a>
          <div class="dropdown-divider"></div>
          <form   method="POST"  enctype="multipart/form-data" action="">
          <a class="dropdown-item" name="logout" href=""><input class="form-control-plaintext" type="submit" name="logout" 
            value="Log out">
          </a>
          </form>
        </div>
      </li>
      <li class="mt-4 d-none d-lg-block"><span class="ml-3"><?php echo($ligne['nom_b']);?></span></li>
      <li class="mt-4 d-none d-lg-block"><span class="ml-3"><?php echo($ligne['prenom']);?></span></li>
      <span class="border-icon d-none d-lg-block"></span>
      <li class="mt-4 d-none d-lg-block"><a href="" class="ml-4 mr-4"><i class="fas fa-bell"></i></a></li>
      <span class="border d-none d-lg-block"></span>
    </ul>
    
  </div>
</nav><br>
<!-- end  nav bar  -->

<!--  Start body  -->
    <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-8 ml-auto mr-auto">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Personal Information</h4>
                  <p class="card-category">Are you looking for more components? </p>
                </div>
                <div class="card-body">
                  <div class="table-responsive table-upgrade">
                   
                    <table class="table">
                      <thead>
                        <tr>
                          <th>Information</th>
                          <th class="text-center"></th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>Name</td>
                          <td class="text-center"><?php echo($ligne['nom_b']);?></td>
                        </tr>
                        <tr>
                          <td>Last Name</td>
                          <td class="text-center"><?php echo($ligne['prenom']);?></td>
                        </tr>
                        <tr>
                          <td>Password</td>
                          <td class="text-center"><?php echo($ligne['mot_pass']);?></td>
                        </tr>
                        <tr>
                          <td>Email</td>
                          <td class="text-center"><?php echo($ligne['email']);?></td>
                        </tr>
                        <tr>
                          <td>Birth Date</td>
                          <td class="text-center"><?php echo($ligne['date_n']);?></td>
                        </tr>
                        <tr>
                          <td>Address</td>
                          <td class="text-center"><?php echo($ligne['adresse']);?></td>
                        </tr>
                        <tr>
                          <td>Number Phone</td>
                          <td class="text-center"><?php echo($ligne['num_tele']);?></td>
                        </tr>
                        <tr>
                          <td>Sexe</td>
                          <td class="text-center"><?php echo($ligne['sexe']);?></td>
                        </tr>
                         <tr>
                          <td>Specialite</td>
                          <td class="text-center"><?php echo($ligne['specialite']);?></td>
                        </tr>
                        <tr>
                          <td>Validation</td>
                          <td class="text-center"><?php echo($ligne['validation']);?> <i class="fa fa-times text-danger"></i></td>
                        </tr>
                        <tr>
                          <td class="text-center"></td>
                          <td class="text-center">
                            <a target="" href="Edit Profil.php" class="btn btn-round btn-fill btn-info">Upd</a>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
                <div class="col-md-4">
              <div class="card card-profile">
                <div class="card-avatar">
                  <a href="#pablo">
                    <img class="img-fluid" src="../image/<?php echo($ligne['photo']);?>" width="400"
                    height="400"/>
                  </a>
                </div>
                <div class="card-body">
                  <h6 class="card-category text-gray">CEO / Co-Founder</h6>
                  <h4 class="card-title"><?php echo($ligne['nom_b']);?> <?php echo($ligne['prenom']);?></h4>
                  <p class="card-description"><?php echo($ligne['description']);?></p>
                  <a href="#pablo" class="btn btn-primary btn-round">Follow</a>
                </div>
              </div>
          </div>



<!--  container  -->
        </div>
      </div>
    </div>
<?php } ?>
<!--  end body  -->


<!--===============================================================================================-->
  <script src="../jQuery/jquery-3.4.1.min.js"></script>
<!--===============================================================================================-->
  <script src="../jQuery/popper.min.js"></script>
<!--===============================================================================================-->
  <script src="../bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->

</body>
<br>
<hr>
<footer class="footer">
        <div class="container-fluid">
          <nav class="float-left">
            <ul class="ul-footer " >
              <li >
                <a href="https://www.creative-tim.com">
                  Creative Tim
                </a>
              </li>
              <li>
                <a href="https://creative-tim.com/presentation">
                  About Us
                </a>
              </li>
              <li>
                <a href="http://blog.creative-tim.com">
                  Blog
                </a>
              </li>
              <li>
                <a href="https://www.creative-tim.com/license">
                  Licenses
                </a>
              </li>
            </ul>
          </nav>
          <div class="copyright float-right">
            &copy;
            <script>
              document.write(new Date().getFullYear())
            </script>, made with <i class="material-icons">favorite</i> by
            <a href="https://www.creative-tim.com" target="_blank">Creative Tim</a> for a better web.
          </div>
        </div>
      </footer>

</html>