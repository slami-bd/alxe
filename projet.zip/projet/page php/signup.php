<?php 
session_start();
require_once('connection.php');

$_SESSION['ident']='a';

// _______________________________________benevol______________________________________//

if(isset($_POST['botton_b'])) {
   $nom=$_POST['nom'];
   $prenom=$_POST['prenom'];
   $email=$_POST['email'];
   $mot_pass=$_POST['mot_pass'];
   $adresse=$_POST['adresse'];
   $num_tele=$_POST['num_tele'];
   $date =$_POST['date'];
   $sexe =$_POST['sexe'];
   $specialite =$_POST['specialite'];
   $description =$_POST['description'];

    if ($_FILES['photo']['error']==0){
   $nom=$_POST['nom'];
   $prenom=$_POST['prenom'];
   $email=$_POST['email'];
   $mot_pass=$_POST['mot_pass'];
   $adresse=$_POST['adresse'];
   $num_tele=$_POST['num_tele'];
   $date =$_POST['date'];
   $sexe =$_POST['sexe'];
   $specialite =$_POST['specialite'];
   $description =$_POST['description'];
   $photo=$_FILES['photo']['name'];

   copy($_FILES['photo']['tmp_name'], "../image/".$_FILES['photo']['name']);

   $requet="insert into benevol(nom_b,prenom,email,mot_pass,adresse,num_tele,date_n,sexe,photo,specialite,description) values ('$nom','$prenom','$email','$mot_pass','$adresse','$num_tele','$date','$sexe','$photo','$specialite','$description')";
 }else

   $requet="insert into benevol(nom_b,prenom,email,mot_pass,adresse,num_tele,date_n,sexe,specialite,description) values ('$nom','$prenom','$email','$mot_pass','$adresse','$num_tele','$date','$sexe','$specialite','$description')";
  mysqli_query($connect,$requet);
  header('location:profil.php');
}
  

// _______________________________________ensignan______________________________________//


?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>sign up</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->  
  <link rel="icon" type="image/png" href=""/>
<!--===============================================================================================-->
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!--===============================================================================================-->
    <link href="../style css/animate.css" rel="stylesheet">
<!--===============================================================================================-->
    <link href="../style css/signup.css" rel="stylesheet">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
	  <div class="container">
	    <div class="wrap" >
          <div class="row">
            <div class="col-md-6  mx-auto">
              <div class="card mt-3 mb-3 form">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Create Profile</h4>
                  <p class="card-category">Full your Information</p>
                </div>
                <div class="card-body">
                  <form   method="POST"  enctype="multipart/form-data" action="">
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">First Name</label>
                          <input type="text" class="form-control" name="nom" >
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Last Name</label>
                          <input type="text" class="form-control" name="prenom" >
                        </div>
                      </div>
                     
                    </div>
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <label class="bmd-label-floating">Email address</label>
                          <input type="email" class="form-control" name="email" placeholder="example@gmail.com">
                        </div>
                      </div>
                  	</div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Password</label>
                          <input type="text" class="form-control" name="mot_pass">
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Birth Day</label>
                          <input type="Date" class="form-control" name="date" >
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Adress</label>
                          <input type="text" class="form-control" name="adresse" >
                        </div>
                      </div>
                       <div class="col-md-6">
                        <label class="bmd-label-floating">image</label>
                         <div class="form-group custom-file">
                          <input type="file" class="custom-file-input" name="photo" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
                          <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                         </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Number Phone</label>
                          <input type="tel" class="form-control" name="num_tele" >
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Sexe</label>
                          <select class="form-control" name="sexe">
                            <option placeholder="Homme">Homme</option>
                            <option placeholder="Femme">Femme</option>
                            <option placeholder="autre">autre</option>
                        </select>
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Specialite</label>
                          <select class="form-control" name="specialite">
                            <option placeholder="other">Other</option>
                            <option placeholder="Specialist medicine">Specialist Medicine</option>
                            <option placeholder="General Medicine">General Medicine</option>
                            <option placeholder="dentist">Dentist</option>
                        </select>                        
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <label>About Me</label>
                          <div class="form-group">
                            <label class="bmd-label-floating"> What can you say about yourself.</label>
                            <textarea class="form-control" rows="3" name="description"></textarea>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div class="float-right mb-3">
                      <a href="../index.php" class="txt3  ">Log In ?</a>
                    </div>

                    <div class="">
            						<a href="">
            						 <input class="col-md-4 p-3 rounded-pill btn btn-dark bot" name="botton_b" type="submit"  value="Sign Up">
            						</a>  
					          </div>  

                    <div class="clearfix"></div>
                    
                  </form>
                </div>
              </div>
             </div>
            </div>
           </div>
    		  </div>
    	   </div>
	
<!--===============================================================================================-->
  <script src="../jQuery/jquery-3.4.1.min.js"></script>
<!--===============================================================================================-->
  <script src="../jQuery/popper.min.js"></script>
<!--===============================================================================================-->
  <script src="../bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->

</body>
</html>