<?php
session_start();
require_once('page php/connection.php');
	@$name=$_POST['nom'];
	@$password=$_POST['mot_pass'];

	@$_SESSION['name']=$_POST['nom'];
	@$_SESSION['password']=$_POST['mot_pass'];

	$requete="select * from adminstrateur where nom='$name' ";
	$req=mysqli_query($connect,$requete);
	$ligne=mysqli_fetch_array($req);
	@$genre_a=$ligne['genre'];
	@$_SESSION['id_admin']=$ligne['id_admin'];

	$requete="select * from benevol where nom_b='$name' ";
	$req=mysqli_query($connect,$requete);
	$ligne_b=mysqli_fetch_array($req);
	@$genre_b=$ligne_b['genre'];
	@$_SESSION['id_benevol']=$ligne_b['id_benevol'];


if (isset($_POST['botton']) and $genre_a=='admin') {
	if ($name==$ligne['nom'] and $password==$ligne['mot_pass']) 
		$_SESSION['id_admin'];
		header('location:page php/list table.php');
}

if (isset($_POST['botton']) and $genre_b=='benevol') {
	if ($name==$ligne_b['nom_b'] and $password==$ligne_b['mot_pass']) 
		$_SESSION['id_benevol'];
		$_SESSION['ident_q']='true';
		header('location:page php/profil.php');
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href=""/>
<!--===============================================================================================-->
	  <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!--===============================================================================================-->
	  <link href="style css/animate.css" rel="stylesheet">
<!--===============================================================================================-->
	  <link href="style css/login.css" rel="stylesheet">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container">
			<div class="row" >
			  <div class="card col-xm-5 mx-auto  login">
			   <div class="card-body">
				   
				<form class="container"  method="POST">
					<div class="form-group">
					<div class="mt-4 animated bounce">
						<span class="title ">ACCOUNT LOGIN</span>
					</div><br>
				  <div class="row">
					<div class="col-md-12">
						<span class="">USERNAME</span>
						<div class="mt-2" data-validate = "Username is required">
							<input class="col-md-12 input form-control" type="text" name="nom" >
							<span class=""></span>
						</div>
					</div>
				  </div><br>

					<div class="row">
					  <div class="col-md-12">
						<span class="card-title ">PASSWORD</span>
						<div class="mt-2" data-validate = "Password is required">
							<span class="btn-show-pass">
								<i class="fa fa-eye"></i>
							</span>
							<input class="col-md-12 input form-control" type="password" name="mot_pass" >
							<span class=""></span>
						</div>
					  </div>
					</div><br>

					<div class="row">
						<div class="col-md-9">
							<input class="" id="ckb1" type="checkbox" name="remember-me">
							<label class="" for="ckb1">Remember me</label>
						</div>

						<div class="col-md-3 float-right">
							<a href="page php/signup.php" class="">
								Sign Up ?
							</a>
						</div>
					</div>
					<div class="row botton">
						<div class="col-md-6 ">
							<input class="bot col-md-8 p-3 rounded-pill btn btn-dark " name="botton" type="submit"  value="Login">
						</div>
				    </div>
				   </div>
				</form>
			   </div>
			  </div>
			</div>
		</div>
	</div>
	

	
<!--===============================================================================================-->
	<script src="jQuery/jquery-3.4.1.min.js"></script>
<!--===============================================================================================-->
	<script src="jQuery/popper.min.js"></script>
<!--===============================================================================================-->
	<script src="bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->

</body>
</html>